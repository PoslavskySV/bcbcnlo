(* Created with the Wolfram Language : www.wolfram.com *)
(-4*alphaS^2*e^4*fBc^4*(MB + MC)^4*Pi*(2*MB + 2*MC - Sqrt[s])*
  (2*MB + 2*MC + Sqrt[s])*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
  (12*MB^12 + 48*MB^11*MC + 72*MB^10*MC^2 + 48*MB^9*MC^3 + 60*MB^8*MC^4 + 
   192*MB^7*MC^5 + 288*MB^6*MC^6 + 192*MB^5*MC^7 + 96*MB^4*MC^8 + 
   192*MB^3*MC^9 + 288*MB^2*MC^10 + 192*MB*MC^11 + 48*MC^12 + 4*MB^10*s + 
   20*MB^9*MC*s + 32*MB^8*MC^2*s + 44*MB^7*MC^3*s + 84*MB^6*MC^4*s + 
   112*MB^5*MC^5*s + 96*MB^4*MC^6*s + 104*MB^3*MC^7*s + 128*MB^2*MC^8*s + 
   80*MB*MC^9*s + 16*MC^10*s + MB^6*MC^2*s^2 + 4*MB^4*MC^4*s^2 + 
   4*MB^2*MC^6*s^2))/(2187*MB^6*MC^6*s^(13/2))
