(* Created with the Wolfram Language : www.wolfram.com *)
(alphaS^2*(-1 + cos)*(1 + cos)*e^4*fBc^4*(MB + MC)^4*Pi*
  (4*MB^2 + 8*MB*MC + 4*MC^2 - s)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
  (2*MB^6 + 4*MB^5*MC + 2*MB^4*MC^2 + 4*MB^2*MC^4 + 8*MB*MC^5 + 4*MC^6 - 
    MB^3*MC*s - 2*MB*MC^3*s)^2)/(729*MB^6*MC^6*s^(13/2))
