(* Created with the Wolfram Language : www.wolfram.com *)
-(alphaS^2*e^4*fBc^4*(MB + MC)^4*Pi*(2*MB + 2*MC - Sqrt[s])*
   (2*MB + 2*MC + Sqrt[s])*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
   (36*MB^12*s^2 + 144*MB^11*MC*s^2 + 216*MB^10*MC^2*s^2 + 
    144*MB^9*MC^3*s^2 + 108*MB^8*MC^4*s^2 + 288*MB^7*MC^5*s^2 + 
    432*MB^6*MC^6*s^2 + 288*MB^5*MC^7*s^2 + 108*MB^4*MC^8*s^2 + 
    144*MB^3*MC^9*s^2 + 216*MB^2*MC^10*s^2 + 144*MB*MC^11*s^2 + 
    36*MC^12*s^2 - 36*MB^9*MC*s^3 - 72*MB^8*MC^2*s^3 - 72*MB^7*MC^3*s^3 - 
    72*MB^6*MC^4*s^3 - 72*MB^5*MC^5*s^3 - 72*MB^4*MC^6*s^3 - 
    72*MB^3*MC^7*s^3 - 72*MB^2*MC^8*s^3 - 36*MB*MC^9*s^3 + 9*MB^6*MC^2*s^4 + 
    18*MB^4*MC^4*s^4 + 9*MB^2*MC^6*s^4 - 192*CW^2*MB^12*MZ^2*s*SW^2 - 
    768*CW^2*MB^11*MC*MZ^2*s*SW^2 - 1152*CW^2*MB^10*MC^2*MZ^2*s*SW^2 - 
    768*CW^2*MB^9*MC^3*MZ^2*s*SW^2 - 768*CW^2*MB^8*MC^4*MZ^2*s*SW^2 - 
    2304*CW^2*MB^7*MC^5*MZ^2*s*SW^2 - 3456*CW^2*MB^6*MC^6*MZ^2*s*SW^2 - 
    2304*CW^2*MB^5*MC^7*MZ^2*s*SW^2 - 960*CW^2*MB^4*MC^8*MZ^2*s*SW^2 - 
    1536*CW^2*MB^3*MC^9*MZ^2*s*SW^2 - 2304*CW^2*MB^2*MC^10*MZ^2*s*SW^2 - 
    1536*CW^2*MB*MC^11*MZ^2*s*SW^2 - 384*CW^2*MC^12*MZ^2*s*SW^2 - 
    240*MB^12*s^2*SW^2 + 192*CW^2*MB^12*s^2*SW^2 - 960*MB^11*MC*s^2*SW^2 + 
    768*CW^2*MB^11*MC*s^2*SW^2 - 1440*MB^10*MC^2*s^2*SW^2 + 
    1152*CW^2*MB^10*MC^2*s^2*SW^2 - 960*MB^9*MC^3*s^2*SW^2 + 
    768*CW^2*MB^9*MC^3*s^2*SW^2 - 816*MB^8*MC^4*s^2*SW^2 + 
    768*CW^2*MB^8*MC^4*s^2*SW^2 - 2304*MB^7*MC^5*s^2*SW^2 + 
    2304*CW^2*MB^7*MC^5*s^2*SW^2 - 3456*MB^6*MC^6*s^2*SW^2 + 
    3456*CW^2*MB^6*MC^6*s^2*SW^2 - 2304*MB^5*MC^7*s^2*SW^2 + 
    2304*CW^2*MB^5*MC^7*s^2*SW^2 - 912*MB^4*MC^8*s^2*SW^2 + 
    960*CW^2*MB^4*MC^8*s^2*SW^2 - 1344*MB^3*MC^9*s^2*SW^2 + 
    1536*CW^2*MB^3*MC^9*s^2*SW^2 - 2016*MB^2*MC^10*s^2*SW^2 + 
    2304*CW^2*MB^2*MC^10*s^2*SW^2 - 1344*MB*MC^11*s^2*SW^2 + 
    1536*CW^2*MB*MC^11*s^2*SW^2 - 336*MC^12*s^2*SW^2 + 
    384*CW^2*MC^12*s^2*SW^2 + 192*CW^2*MB^9*MC*MZ^2*s^2*SW^2 + 
    384*CW^2*MB^8*MC^2*MZ^2*s^2*SW^2 + 480*CW^2*MB^7*MC^3*MZ^2*s^2*SW^2 + 
    576*CW^2*MB^6*MC^4*MZ^2*s^2*SW^2 + 576*CW^2*MB^5*MC^5*MZ^2*s^2*SW^2 + 
    576*CW^2*MB^4*MC^6*MZ^2*s^2*SW^2 + 672*CW^2*MB^3*MC^7*MZ^2*s^2*SW^2 + 
    768*CW^2*MB^2*MC^8*MZ^2*s^2*SW^2 + 384*CW^2*MB*MC^9*MZ^2*s^2*SW^2 + 
    240*MB^9*MC*s^3*SW^2 - 192*CW^2*MB^9*MC*s^3*SW^2 + 
    480*MB^8*MC^2*s^3*SW^2 - 384*CW^2*MB^8*MC^2*s^3*SW^2 + 
    528*MB^7*MC^3*s^3*SW^2 - 480*CW^2*MB^7*MC^3*s^3*SW^2 + 
    576*MB^6*MC^4*s^3*SW^2 - 576*CW^2*MB^6*MC^4*s^3*SW^2 + 
    576*MB^5*MC^5*s^3*SW^2 - 576*CW^2*MB^5*MC^5*s^3*SW^2 + 
    576*MB^4*MC^6*s^3*SW^2 - 576*CW^2*MB^4*MC^6*s^3*SW^2 + 
    624*MB^3*MC^7*s^3*SW^2 - 672*CW^2*MB^3*MC^7*s^3*SW^2 + 
    672*MB^2*MC^8*s^3*SW^2 - 768*CW^2*MB^2*MC^8*s^3*SW^2 + 
    336*MB*MC^9*s^3*SW^2 - 384*CW^2*MB*MC^9*s^3*SW^2 - 
    48*CW^2*MB^6*MC^2*MZ^2*s^3*SW^2 - 144*CW^2*MB^4*MC^4*MZ^2*s^3*SW^2 - 
    96*CW^2*MB^2*MC^6*MZ^2*s^3*SW^2 - 60*MB^6*MC^2*s^4*SW^2 + 
    48*CW^2*MB^6*MC^2*s^4*SW^2 - 144*MB^4*MC^4*s^4*SW^2 + 
    144*CW^2*MB^4*MC^4*s^4*SW^2 - 84*MB^2*MC^6*s^4*SW^2 + 
    96*CW^2*MB^2*MC^6*s^4*SW^2 + 512*CW^4*GammaZ^2*MB^12*MZ^2*SW^4 + 
    2048*CW^4*GammaZ^2*MB^11*MC*MZ^2*SW^4 + 3072*CW^4*GammaZ^2*MB^10*MC^2*
     MZ^2*SW^4 + 2048*CW^4*GammaZ^2*MB^9*MC^3*MZ^2*SW^4 + 
    2560*CW^4*GammaZ^2*MB^8*MC^4*MZ^2*SW^4 + 8192*CW^4*GammaZ^2*MB^7*MC^5*
     MZ^2*SW^4 + 12288*CW^4*GammaZ^2*MB^6*MC^6*MZ^2*SW^4 + 
    8192*CW^4*GammaZ^2*MB^5*MC^7*MZ^2*SW^4 + 4096*CW^4*GammaZ^2*MB^4*MC^8*
     MZ^2*SW^4 + 8192*CW^4*GammaZ^2*MB^3*MC^9*MZ^2*SW^4 + 
    12288*CW^4*GammaZ^2*MB^2*MC^10*MZ^2*SW^4 + 8192*CW^4*GammaZ^2*MB*MC^11*
     MZ^2*SW^4 + 2048*CW^4*GammaZ^2*MC^12*MZ^2*SW^4 + 
    512*CW^4*MB^12*MZ^4*SW^4 + 2048*CW^4*MB^11*MC*MZ^4*SW^4 + 
    3072*CW^4*MB^10*MC^2*MZ^4*SW^4 + 2048*CW^4*MB^9*MC^3*MZ^4*SW^4 + 
    2560*CW^4*MB^8*MC^4*MZ^4*SW^4 + 8192*CW^4*MB^7*MC^5*MZ^4*SW^4 + 
    12288*CW^4*MB^6*MC^6*MZ^4*SW^4 + 8192*CW^4*MB^5*MC^7*MZ^4*SW^4 + 
    4096*CW^4*MB^4*MC^8*MZ^4*SW^4 + 8192*CW^4*MB^3*MC^9*MZ^4*SW^4 + 
    12288*CW^4*MB^2*MC^10*MZ^4*SW^4 + 8192*CW^4*MB*MC^11*MZ^4*SW^4 + 
    2048*CW^4*MC^12*MZ^4*SW^4 + 1024*CW^2*MB^12*MZ^2*s*SW^4 - 
    1024*CW^4*MB^12*MZ^2*s*SW^4 - 512*CW^4*GammaZ^2*MB^9*MC*MZ^2*s*SW^4 + 
    4096*CW^2*MB^11*MC*MZ^2*s*SW^4 - 4096*CW^4*MB^11*MC*MZ^2*s*SW^4 - 
    1024*CW^4*GammaZ^2*MB^8*MC^2*MZ^2*s*SW^4 + 6144*CW^2*MB^10*MC^2*MZ^2*s*
     SW^4 - 6144*CW^4*MB^10*MC^2*MZ^2*s*SW^4 - 1536*CW^4*GammaZ^2*MB^7*MC^3*
     MZ^2*s*SW^4 + 4096*CW^2*MB^9*MC^3*MZ^2*s*SW^4 - 
    4096*CW^4*MB^9*MC^3*MZ^2*s*SW^4 - 2048*CW^4*GammaZ^2*MB^6*MC^4*MZ^2*s*
     SW^4 + 4352*CW^2*MB^8*MC^4*MZ^2*s*SW^4 - 5120*CW^4*MB^8*MC^4*MZ^2*s*
     SW^4 - 2048*CW^4*GammaZ^2*MB^5*MC^5*MZ^2*s*SW^4 + 
    13312*CW^2*MB^7*MC^5*MZ^2*s*SW^4 - 16384*CW^4*MB^7*MC^5*MZ^2*s*SW^4 - 
    2048*CW^4*GammaZ^2*MB^4*MC^6*MZ^2*s*SW^4 + 19968*CW^2*MB^6*MC^6*MZ^2*s*
     SW^4 - 24576*CW^4*MB^6*MC^6*MZ^2*s*SW^4 - 3072*CW^4*GammaZ^2*MB^3*MC^7*
     MZ^2*s*SW^4 + 13312*CW^2*MB^5*MC^7*MZ^2*s*SW^4 - 
    16384*CW^4*MB^5*MC^7*MZ^2*s*SW^4 - 4096*CW^4*GammaZ^2*MB^2*MC^8*MZ^2*s*
     SW^4 + 5888*CW^2*MB^4*MC^8*MZ^2*s*SW^4 - 8192*CW^4*MB^4*MC^8*MZ^2*s*
     SW^4 - 2048*CW^4*GammaZ^2*MB*MC^9*MZ^2*s*SW^4 + 
    10240*CW^2*MB^3*MC^9*MZ^2*s*SW^4 - 16384*CW^4*MB^3*MC^9*MZ^2*s*SW^4 + 
    15360*CW^2*MB^2*MC^10*MZ^2*s*SW^4 - 24576*CW^4*MB^2*MC^10*MZ^2*s*SW^4 + 
    10240*CW^2*MB*MC^11*MZ^2*s*SW^4 - 16384*CW^4*MB*MC^11*MZ^2*s*SW^4 + 
    2560*CW^2*MC^12*MZ^2*s*SW^4 - 4096*CW^4*MC^12*MZ^2*s*SW^4 - 
    512*CW^4*MB^9*MC*MZ^4*s*SW^4 - 1024*CW^4*MB^8*MC^2*MZ^4*s*SW^4 - 
    1536*CW^4*MB^7*MC^3*MZ^4*s*SW^4 - 2048*CW^4*MB^6*MC^4*MZ^4*s*SW^4 - 
    2048*CW^4*MB^5*MC^5*MZ^4*s*SW^4 - 2048*CW^4*MB^4*MC^6*MZ^4*s*SW^4 - 
    3072*CW^4*MB^3*MC^7*MZ^4*s*SW^4 - 4096*CW^4*MB^2*MC^8*MZ^4*s*SW^4 - 
    2048*CW^4*MB*MC^9*MZ^4*s*SW^4 + 736*MB^12*s^2*SW^4 - 
    1024*CW^2*MB^12*s^2*SW^4 + 512*CW^4*MB^12*s^2*SW^4 + 
    2944*MB^11*MC*s^2*SW^4 - 4096*CW^2*MB^11*MC*s^2*SW^4 + 
    2048*CW^4*MB^11*MC*s^2*SW^4 + 4416*MB^10*MC^2*s^2*SW^4 - 
    6144*CW^2*MB^10*MC^2*s^2*SW^4 + 3072*CW^4*MB^10*MC^2*s^2*SW^4 + 
    2944*MB^9*MC^3*s^2*SW^4 - 4096*CW^2*MB^9*MC^3*s^2*SW^4 + 
    2048*CW^4*MB^9*MC^3*s^2*SW^4 + 2720*MB^8*MC^4*s^2*SW^4 - 
    4352*CW^2*MB^8*MC^4*s^2*SW^4 + 2560*CW^4*MB^8*MC^4*s^2*SW^4 + 
    7936*MB^7*MC^5*s^2*SW^4 - 13312*CW^2*MB^7*MC^5*s^2*SW^4 + 
    8192*CW^4*MB^7*MC^5*s^2*SW^4 + 11904*MB^6*MC^6*s^2*SW^4 - 
    19968*CW^2*MB^6*MC^6*s^2*SW^4 + 12288*CW^4*MB^6*MC^6*s^2*SW^4 + 
    7936*MB^5*MC^7*s^2*SW^4 - 13312*CW^2*MB^5*MC^7*s^2*SW^4 + 
    8192*CW^4*MB^5*MC^7*s^2*SW^4 + 3296*MB^4*MC^8*s^2*SW^4 - 
    5888*CW^2*MB^4*MC^8*s^2*SW^4 + 4096*CW^4*MB^4*MC^8*s^2*SW^4 + 
    5248*MB^3*MC^9*s^2*SW^4 - 10240*CW^2*MB^3*MC^9*s^2*SW^4 + 
    8192*CW^4*MB^3*MC^9*s^2*SW^4 + 7872*MB^2*MC^10*s^2*SW^4 - 
    15360*CW^2*MB^2*MC^10*s^2*SW^4 + 12288*CW^4*MB^2*MC^10*s^2*SW^4 + 
    5248*MB*MC^11*s^2*SW^4 - 10240*CW^2*MB*MC^11*s^2*SW^4 + 
    8192*CW^4*MB*MC^11*s^2*SW^4 + 1312*MC^12*s^2*SW^4 - 
    2560*CW^2*MC^12*s^2*SW^4 + 2048*CW^4*MC^12*s^2*SW^4 - 
    1024*CW^2*MB^9*MC*MZ^2*s^2*SW^4 + 1024*CW^4*MB^9*MC*MZ^2*s^2*SW^4 + 
    128*CW^4*GammaZ^2*MB^6*MC^2*MZ^2*s^2*SW^4 - 2048*CW^2*MB^8*MC^2*MZ^2*s^2*
     SW^4 + 2048*CW^4*MB^8*MC^2*MZ^2*s^2*SW^4 - 2688*CW^2*MB^7*MC^3*MZ^2*s^2*
     SW^4 + 3072*CW^4*MB^7*MC^3*MZ^2*s^2*SW^4 + 512*CW^4*GammaZ^2*MB^4*MC^4*
     MZ^2*s^2*SW^4 - 3328*CW^2*MB^6*MC^4*MZ^2*s^2*SW^4 + 
    4096*CW^4*MB^6*MC^4*MZ^2*s^2*SW^4 - 3328*CW^2*MB^5*MC^5*MZ^2*s^2*SW^4 + 
    4096*CW^4*MB^5*MC^5*MZ^2*s^2*SW^4 + 512*CW^4*GammaZ^2*MB^2*MC^6*MZ^2*s^2*
     SW^4 - 3328*CW^2*MB^4*MC^6*MZ^2*s^2*SW^4 + 4096*CW^4*MB^4*MC^6*MZ^2*s^2*
     SW^4 - 4224*CW^2*MB^3*MC^7*MZ^2*s^2*SW^4 + 6144*CW^4*MB^3*MC^7*MZ^2*s^2*
     SW^4 - 5120*CW^2*MB^2*MC^8*MZ^2*s^2*SW^4 + 8192*CW^4*MB^2*MC^8*MZ^2*s^2*
     SW^4 - 2560*CW^2*MB*MC^9*MZ^2*s^2*SW^4 + 4096*CW^4*MB*MC^9*MZ^2*s^2*
     SW^4 + 128*CW^4*MB^6*MC^2*MZ^4*s^2*SW^4 + 512*CW^4*MB^4*MC^4*MZ^4*s^2*
     SW^4 + 512*CW^4*MB^2*MC^6*MZ^4*s^2*SW^4 - 736*MB^9*MC*s^3*SW^4 + 
    1024*CW^2*MB^9*MC*s^3*SW^4 - 512*CW^4*MB^9*MC*s^3*SW^4 - 
    1472*MB^8*MC^2*s^3*SW^4 + 2048*CW^2*MB^8*MC^2*s^3*SW^4 - 
    1024*CW^4*MB^8*MC^2*s^3*SW^4 - 1728*MB^7*MC^3*s^3*SW^4 + 
    2688*CW^2*MB^7*MC^3*s^3*SW^4 - 1536*CW^4*MB^7*MC^3*s^3*SW^4 - 
    1984*MB^6*MC^4*s^3*SW^4 + 3328*CW^2*MB^6*MC^4*s^3*SW^4 - 
    2048*CW^4*MB^6*MC^4*s^3*SW^4 - 1984*MB^5*MC^5*s^3*SW^4 + 
    3328*CW^2*MB^5*MC^5*s^3*SW^4 - 2048*CW^4*MB^5*MC^5*s^3*SW^4 - 
    1984*MB^4*MC^6*s^3*SW^4 + 3328*CW^2*MB^4*MC^6*s^3*SW^4 - 
    2048*CW^4*MB^4*MC^6*s^3*SW^4 - 2304*MB^3*MC^7*s^3*SW^4 + 
    4224*CW^2*MB^3*MC^7*s^3*SW^4 - 3072*CW^4*MB^3*MC^7*s^3*SW^4 - 
    2624*MB^2*MC^8*s^3*SW^4 + 5120*CW^2*MB^2*MC^8*s^3*SW^4 - 
    4096*CW^4*MB^2*MC^8*s^3*SW^4 - 1312*MB*MC^9*s^3*SW^4 + 
    2560*CW^2*MB*MC^9*s^3*SW^4 - 2048*CW^4*MB*MC^9*s^3*SW^4 + 
    256*CW^2*MB^6*MC^2*MZ^2*s^3*SW^4 - 256*CW^4*MB^6*MC^2*MZ^2*s^3*SW^4 + 
    832*CW^2*MB^4*MC^4*MZ^2*s^3*SW^4 - 1024*CW^4*MB^4*MC^4*MZ^2*s^3*SW^4 + 
    640*CW^2*MB^2*MC^6*MZ^2*s^3*SW^4 - 1024*CW^4*MB^2*MC^6*MZ^2*s^3*SW^4 + 
    184*MB^6*MC^2*s^4*SW^4 - 256*CW^2*MB^6*MC^2*s^4*SW^4 + 
    128*CW^4*MB^6*MC^2*s^4*SW^4 + 496*MB^4*MC^4*s^4*SW^4 - 
    832*CW^2*MB^4*MC^4*s^4*SW^4 + 512*CW^4*MB^4*MC^4*s^4*SW^4 + 
    328*MB^2*MC^6*s^4*SW^4 - 640*CW^2*MB^2*MC^6*s^4*SW^4 + 
    512*CW^4*MB^2*MC^6*s^4*SW^4 - 1024*CW^2*MB^12*MZ^2*s*SW^6 - 
    4096*CW^2*MB^11*MC*MZ^2*s*SW^6 - 6144*CW^2*MB^10*MC^2*MZ^2*s*SW^6 - 
    4096*CW^2*MB^9*MC^3*MZ^2*s*SW^6 - 5120*CW^2*MB^8*MC^4*MZ^2*s*SW^6 - 
    16384*CW^2*MB^7*MC^5*MZ^2*s*SW^6 - 24576*CW^2*MB^6*MC^6*MZ^2*s*SW^6 - 
    16384*CW^2*MB^5*MC^7*MZ^2*s*SW^6 - 8192*CW^2*MB^4*MC^8*MZ^2*s*SW^6 - 
    16384*CW^2*MB^3*MC^9*MZ^2*s*SW^6 - 24576*CW^2*MB^2*MC^10*MZ^2*s*SW^6 - 
    16384*CW^2*MB*MC^11*MZ^2*s*SW^6 - 4096*CW^2*MC^12*MZ^2*s*SW^6 - 
    1024*MB^12*s^2*SW^6 + 1024*CW^2*MB^12*s^2*SW^6 - 4096*MB^11*MC*s^2*SW^6 + 
    4096*CW^2*MB^11*MC*s^2*SW^6 - 6144*MB^10*MC^2*s^2*SW^6 + 
    6144*CW^2*MB^10*MC^2*s^2*SW^6 - 4096*MB^9*MC^3*s^2*SW^6 + 
    4096*CW^2*MB^9*MC^3*s^2*SW^6 - 4352*MB^8*MC^4*s^2*SW^6 + 
    5120*CW^2*MB^8*MC^4*s^2*SW^6 - 13312*MB^7*MC^5*s^2*SW^6 + 
    16384*CW^2*MB^7*MC^5*s^2*SW^6 - 19968*MB^6*MC^6*s^2*SW^6 + 
    24576*CW^2*MB^6*MC^6*s^2*SW^6 - 13312*MB^5*MC^7*s^2*SW^6 + 
    16384*CW^2*MB^5*MC^7*s^2*SW^6 - 5888*MB^4*MC^8*s^2*SW^6 + 
    8192*CW^2*MB^4*MC^8*s^2*SW^6 - 10240*MB^3*MC^9*s^2*SW^6 + 
    16384*CW^2*MB^3*MC^9*s^2*SW^6 - 15360*MB^2*MC^10*s^2*SW^6 + 
    24576*CW^2*MB^2*MC^10*s^2*SW^6 - 10240*MB*MC^11*s^2*SW^6 + 
    16384*CW^2*MB*MC^11*s^2*SW^6 - 2560*MC^12*s^2*SW^6 + 
    4096*CW^2*MC^12*s^2*SW^6 + 1024*CW^2*MB^9*MC*MZ^2*s^2*SW^6 + 
    2048*CW^2*MB^8*MC^2*MZ^2*s^2*SW^6 + 3072*CW^2*MB^7*MC^3*MZ^2*s^2*SW^6 + 
    4096*CW^2*MB^6*MC^4*MZ^2*s^2*SW^6 + 4096*CW^2*MB^5*MC^5*MZ^2*s^2*SW^6 + 
    4096*CW^2*MB^4*MC^6*MZ^2*s^2*SW^6 + 6144*CW^2*MB^3*MC^7*MZ^2*s^2*SW^6 + 
    8192*CW^2*MB^2*MC^8*MZ^2*s^2*SW^6 + 4096*CW^2*MB*MC^9*MZ^2*s^2*SW^6 + 
    1024*MB^9*MC*s^3*SW^6 - 1024*CW^2*MB^9*MC*s^3*SW^6 + 
    2048*MB^8*MC^2*s^3*SW^6 - 2048*CW^2*MB^8*MC^2*s^3*SW^6 + 
    2688*MB^7*MC^3*s^3*SW^6 - 3072*CW^2*MB^7*MC^3*s^3*SW^6 + 
    3328*MB^6*MC^4*s^3*SW^6 - 4096*CW^2*MB^6*MC^4*s^3*SW^6 + 
    3328*MB^5*MC^5*s^3*SW^6 - 4096*CW^2*MB^5*MC^5*s^3*SW^6 + 
    3328*MB^4*MC^6*s^3*SW^6 - 4096*CW^2*MB^4*MC^6*s^3*SW^6 + 
    4224*MB^3*MC^7*s^3*SW^6 - 6144*CW^2*MB^3*MC^7*s^3*SW^6 + 
    5120*MB^2*MC^8*s^3*SW^6 - 8192*CW^2*MB^2*MC^8*s^3*SW^6 + 
    2560*MB*MC^9*s^3*SW^6 - 4096*CW^2*MB*MC^9*s^3*SW^6 - 
    256*CW^2*MB^6*MC^2*MZ^2*s^3*SW^6 - 1024*CW^2*MB^4*MC^4*MZ^2*s^3*SW^6 - 
    1024*CW^2*MB^2*MC^6*MZ^2*s^3*SW^6 - 256*MB^6*MC^2*s^4*SW^6 + 
    256*CW^2*MB^6*MC^2*s^4*SW^6 - 832*MB^4*MC^4*s^4*SW^6 + 
    1024*CW^2*MB^4*MC^4*s^4*SW^6 - 640*MB^2*MC^6*s^4*SW^6 + 
    1024*CW^2*MB^2*MC^6*s^4*SW^6 + 512*MB^12*s^2*SW^8 + 
    2048*MB^11*MC*s^2*SW^8 + 3072*MB^10*MC^2*s^2*SW^8 + 
    2048*MB^9*MC^3*s^2*SW^8 + 2560*MB^8*MC^4*s^2*SW^8 + 
    8192*MB^7*MC^5*s^2*SW^8 + 12288*MB^6*MC^6*s^2*SW^8 + 
    8192*MB^5*MC^7*s^2*SW^8 + 4096*MB^4*MC^8*s^2*SW^8 + 
    8192*MB^3*MC^9*s^2*SW^8 + 12288*MB^2*MC^10*s^2*SW^8 + 
    8192*MB*MC^11*s^2*SW^8 + 2048*MC^12*s^2*SW^8 - 512*MB^9*MC*s^3*SW^8 - 
    1024*MB^8*MC^2*s^3*SW^8 - 1536*MB^7*MC^3*s^3*SW^8 - 
    2048*MB^6*MC^4*s^3*SW^8 - 2048*MB^5*MC^5*s^3*SW^8 - 
    2048*MB^4*MC^6*s^3*SW^8 - 3072*MB^3*MC^7*s^3*SW^8 - 
    4096*MB^2*MC^8*s^3*SW^8 - 2048*MB*MC^9*s^3*SW^8 + 
    128*MB^6*MC^2*s^4*SW^8 + 512*MB^4*MC^4*s^4*SW^8 + 
    512*MB^2*MC^6*s^4*SW^8))/(69984*CW^4*MB^6*MC^6*s^(13/2)*
  ((-I)*GammaZ*MZ - MZ^2 + s)*(I*GammaZ*MZ - MZ^2 + s)*SW^4)
