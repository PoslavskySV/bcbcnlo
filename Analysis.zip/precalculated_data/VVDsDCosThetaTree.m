(* Created with the Wolfram Language : www.wolfram.com *)
(alphaS^2*e^4*fBc^4*(MB + MC)^4*Pi*(4*MB^2 + 8*MB*MC + 4*MC^2 - s)*
  Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*(-12*MB^12 + 12*cos^2*MB^12 - 
   48*MB^11*MC + 48*cos^2*MB^11*MC - 72*MB^10*MC^2 + 72*cos^2*MB^10*MC^2 - 
   48*MB^9*MC^3 + 48*cos^2*MB^9*MC^3 - 60*MB^8*MC^4 + 60*cos^2*MB^8*MC^4 - 
   192*MB^7*MC^5 + 192*cos^2*MB^7*MC^5 - 288*MB^6*MC^6 + 
   288*cos^2*MB^6*MC^6 - 192*MB^5*MC^7 + 192*cos^2*MB^5*MC^7 - 96*MB^4*MC^8 + 
   96*cos^2*MB^4*MC^8 - 192*MB^3*MC^9 + 192*cos^2*MB^3*MC^9 - 
   288*MB^2*MC^10 + 288*cos^2*MB^2*MC^10 - 192*MB*MC^11 + 
   192*cos^2*MB*MC^11 - 48*MC^12 + 48*cos^2*MC^12 - 2*MB^10*s - 
   2*cos^2*MB^10*s - 12*MB^9*MC*s - 4*cos^2*MB^9*MC*s - 20*MB^8*MC^2*s - 
   4*cos^2*MB^8*MC^2*s - 28*MB^7*MC^3*s - 4*cos^2*MB^7*MC^3*s - 
   50*MB^6*MC^4*s - 18*cos^2*MB^6*MC^4*s - 64*MB^5*MC^5*s - 
   32*cos^2*MB^5*MC^5*s - 56*MB^4*MC^6*s - 24*cos^2*MB^4*MC^6*s - 
   64*MB^3*MC^7*s - 16*cos^2*MB^3*MC^7*s - 80*MB^2*MC^8*s - 
   16*cos^2*MB^2*MC^8*s - 48*MB*MC^9*s - 16*cos^2*MB*MC^9*s - 8*MC^10*s - 
   8*cos^2*MC^10*s - MB^6*MC^2*s^2 + cos^2*MB^6*MC^2*s^2 - 4*MB^4*MC^4*s^2 + 
   4*cos^2*MB^4*MC^4*s^2 - 4*MB^2*MC^6*s^2 + 4*cos^2*MB^2*MC^6*s^2))/
 (729*MB^6*MC^6*s^(13/2))
