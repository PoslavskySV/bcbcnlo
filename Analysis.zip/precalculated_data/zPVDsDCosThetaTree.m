(* Created with the Wolfram Language : www.wolfram.com *)
-(alphaS^2*e^4*fBc^4*(MB + MC)^4*Pi*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
   (-144*MB^14*s - 144*cos^2*MB^14*s - 864*MB^13*MC*s - 
    864*cos^2*MB^13*MC*s - 2160*MB^12*MC^2*s - 2160*cos^2*MB^12*MC^2*s - 
    2880*MB^11*MC^3*s - 2880*cos^2*MB^11*MC^3*s - 2448*MB^10*MC^4*s - 
    2448*cos^2*MB^10*MC^4*s - 2592*MB^9*MC^5*s - 2592*cos^2*MB^9*MC^5*s - 
    4464*MB^8*MC^6*s - 4464*cos^2*MB^8*MC^6*s - 5760*MB^7*MC^7*s - 
    5760*cos^2*MB^7*MC^7*s - 4464*MB^6*MC^8*s - 4464*cos^2*MB^6*MC^8*s - 
    2592*MB^5*MC^9*s - 2592*cos^2*MB^5*MC^9*s - 2448*MB^4*MC^10*s - 
    2448*cos^2*MB^4*MC^10*s - 2880*MB^3*MC^11*s - 2880*cos^2*MB^3*MC^11*s - 
    2160*MB^2*MC^12*s - 2160*cos^2*MB^2*MC^12*s - 864*MB*MC^13*s - 
    864*cos^2*MB*MC^13*s - 144*MC^14*s - 144*cos^2*MC^14*s + 108*MB^12*s^2 + 
    108*cos^2*MB^12*s^2 + 648*MB^11*MC*s^2 + 648*cos^2*MB^11*MC*s^2 + 
    1548*MB^10*MC^2*s^2 + 1548*cos^2*MB^10*MC^2*s^2 + 1944*MB^9*MC^3*s^2 + 
    1944*cos^2*MB^9*MC^3*s^2 + 1476*MB^8*MC^4*s^2 + 
    1476*cos^2*MB^8*MC^4*s^2 + 864*MB^7*MC^5*s^2 + 864*cos^2*MB^7*MC^5*s^2 + 
    648*MB^6*MC^6*s^2 + 648*cos^2*MB^6*MC^6*s^2 + 864*MB^5*MC^7*s^2 + 
    864*cos^2*MB^5*MC^7*s^2 + 1476*MB^4*MC^8*s^2 + 1476*cos^2*MB^4*MC^8*s^2 + 
    1944*MB^3*MC^9*s^2 + 1944*cos^2*MB^3*MC^9*s^2 + 1548*MB^2*MC^10*s^2 + 
    1548*cos^2*MB^2*MC^10*s^2 + 648*MB*MC^11*s^2 + 648*cos^2*MB*MC^11*s^2 + 
    108*MC^12*s^2 + 108*cos^2*MC^12*s^2 - 18*MB^10*s^3 - 18*cos^2*MB^10*s^3 - 
    90*MB^9*MC*s^3 - 90*cos^2*MB^9*MC*s^3 - 171*MB^8*MC^2*s^3 - 
    171*cos^2*MB^8*MC^2*s^3 - 162*MB^7*MC^3*s^3 - 162*cos^2*MB^7*MC^3*s^3 - 
    135*MB^6*MC^4*s^3 - 135*cos^2*MB^6*MC^4*s^3 - 144*MB^5*MC^5*s^3 - 
    144*cos^2*MB^5*MC^5*s^3 - 135*MB^4*MC^6*s^3 - 135*cos^2*MB^4*MC^6*s^3 - 
    162*MB^3*MC^7*s^3 - 162*cos^2*MB^3*MC^7*s^3 - 171*MB^2*MC^8*s^3 - 
    171*cos^2*MB^2*MC^8*s^3 - 90*MB*MC^9*s^3 - 90*cos^2*MB*MC^9*s^3 - 
    18*MC^10*s^3 - 18*cos^2*MC^10*s^3 - 9*MB^6*MC^2*s^4 + 
    9*cos^2*MB^6*MC^2*s^4 - 18*MB^4*MC^4*s^4 + 18*cos^2*MB^4*MC^4*s^4 - 
    9*MB^2*MC^6*s^4 + 9*cos^2*MB^2*MC^6*s^4 - 144*cos*MB^12*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] - 720*cos*MB^11*MC*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] - 1440*cos*MB^10*MC^2*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] - 1296*cos*MB^9*MC^3*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] - 144*cos*MB^8*MC^4*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 576*cos*MB^7*MC^5*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] - 576*cos*MB^5*MC^7*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 144*cos*MB^4*MC^8*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 1296*cos*MB^3*MC^9*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 1440*cos*MB^2*MC^10*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 720*cos*MB*MC^11*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 144*cos*MC^12*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 36*cos*MB^10*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 180*cos*MB^9*MC*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 324*cos*MB^8*MC^2*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 288*cos*MB^7*MC^3*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 144*cos*MB^6*MC^4*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] - 144*cos*MB^4*MC^6*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] - 288*cos*MB^3*MC^7*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] - 324*cos*MB^2*MC^8*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] - 180*cos*MB*MC^9*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] - 36*cos*MC^10*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 576*MB^14*s*SW^2 + 
    576*cos^2*MB^14*s*SW^2 + 3456*MB^13*MC*s*SW^2 + 
    3456*cos^2*MB^13*MC*s*SW^2 + 8640*MB^12*MC^2*s*SW^2 + 
    8640*cos^2*MB^12*MC^2*s*SW^2 + 11520*MB^11*MC^3*s*SW^2 + 
    11520*cos^2*MB^11*MC^3*s*SW^2 + 9792*MB^10*MC^4*s*SW^2 + 
    9792*cos^2*MB^10*MC^4*s*SW^2 + 10368*MB^9*MC^5*s*SW^2 + 
    10368*cos^2*MB^9*MC^5*s*SW^2 + 17856*MB^8*MC^6*s*SW^2 + 
    17856*cos^2*MB^8*MC^6*s*SW^2 + 23040*MB^7*MC^7*s*SW^2 + 
    23040*cos^2*MB^7*MC^7*s*SW^2 + 17856*MB^6*MC^8*s*SW^2 + 
    17856*cos^2*MB^6*MC^8*s*SW^2 + 10368*MB^5*MC^9*s*SW^2 + 
    10368*cos^2*MB^5*MC^9*s*SW^2 + 9792*MB^4*MC^10*s*SW^2 + 
    9792*cos^2*MB^4*MC^10*s*SW^2 + 11520*MB^3*MC^11*s*SW^2 + 
    11520*cos^2*MB^3*MC^11*s*SW^2 + 8640*MB^2*MC^12*s*SW^2 + 
    8640*cos^2*MB^2*MC^12*s*SW^2 + 3456*MB*MC^13*s*SW^2 + 
    3456*cos^2*MB*MC^13*s*SW^2 + 576*MC^14*s*SW^2 + 576*cos^2*MC^14*s*SW^2 - 
    192*CW^2*MB^12*MZ^2*s*SW^2 - 192*cos^2*CW^2*MB^12*MZ^2*s*SW^2 - 
    1152*CW^2*MB^11*MC*MZ^2*s*SW^2 - 1152*cos^2*CW^2*MB^11*MC*MZ^2*s*SW^2 - 
    2880*CW^2*MB^10*MC^2*MZ^2*s*SW^2 - 2880*cos^2*CW^2*MB^10*MC^2*MZ^2*s*
     SW^2 - 3264*CW^2*MB^9*MC^3*MZ^2*s*SW^2 - 3264*cos^2*CW^2*MB^9*MC^3*MZ^2*
     s*SW^2 + 576*CW^2*MB^8*MC^4*MZ^2*s*SW^2 + 576*cos^2*CW^2*MB^8*MC^4*MZ^2*
     s*SW^2 + 7488*CW^2*MB^7*MC^5*MZ^2*s*SW^2 + 7488*cos^2*CW^2*MB^7*MC^5*
     MZ^2*s*SW^2 + 10944*CW^2*MB^6*MC^6*MZ^2*s*SW^2 + 
    10944*cos^2*CW^2*MB^6*MC^6*MZ^2*s*SW^2 + 6336*CW^2*MB^5*MC^7*MZ^2*s*
     SW^2 + 6336*cos^2*CW^2*MB^5*MC^7*MZ^2*s*SW^2 - 
    2304*CW^2*MB^4*MC^8*MZ^2*s*SW^2 - 2304*cos^2*CW^2*MB^4*MC^8*MZ^2*s*SW^2 - 
    7104*CW^2*MB^3*MC^9*MZ^2*s*SW^2 - 7104*cos^2*CW^2*MB^3*MC^9*MZ^2*s*SW^2 - 
    5760*CW^2*MB^2*MC^10*MZ^2*s*SW^2 - 5760*cos^2*CW^2*MB^2*MC^10*MZ^2*s*
     SW^2 - 2304*CW^2*MB*MC^11*MZ^2*s*SW^2 - 2304*cos^2*CW^2*MB*MC^11*MZ^2*s*
     SW^2 - 384*CW^2*MC^12*MZ^2*s*SW^2 - 384*cos^2*CW^2*MC^12*MZ^2*s*SW^2 - 
    528*MB^12*s^2*SW^2 - 528*cos^2*MB^12*s^2*SW^2 + 192*CW^2*MB^12*s^2*SW^2 + 
    192*cos^2*CW^2*MB^12*s^2*SW^2 - 3168*MB^11*MC*s^2*SW^2 - 
    3168*cos^2*MB^11*MC*s^2*SW^2 + 1152*CW^2*MB^11*MC*s^2*SW^2 + 
    1152*cos^2*CW^2*MB^11*MC*s^2*SW^2 - 7632*MB^10*MC^2*s^2*SW^2 - 
    7632*cos^2*MB^10*MC^2*s^2*SW^2 + 2880*CW^2*MB^10*MC^2*s^2*SW^2 + 
    2880*cos^2*CW^2*MB^10*MC^2*s^2*SW^2 - 9408*MB^9*MC^3*s^2*SW^2 - 
    9408*cos^2*MB^9*MC^3*s^2*SW^2 + 3264*CW^2*MB^9*MC^3*s^2*SW^2 + 
    3264*cos^2*CW^2*MB^9*MC^3*s^2*SW^2 - 5616*MB^8*MC^4*s^2*SW^2 - 
    5616*cos^2*MB^8*MC^4*s^2*SW^2 - 576*CW^2*MB^8*MC^4*s^2*SW^2 - 
    576*cos^2*CW^2*MB^8*MC^4*s^2*SW^2 + 288*MB^7*MC^5*s^2*SW^2 + 
    288*cos^2*MB^7*MC^5*s^2*SW^2 - 7488*CW^2*MB^7*MC^5*s^2*SW^2 - 
    7488*cos^2*CW^2*MB^7*MC^5*s^2*SW^2 + 2880*MB^6*MC^6*s^2*SW^2 + 
    2880*cos^2*MB^6*MC^6*s^2*SW^2 - 10944*CW^2*MB^6*MC^6*s^2*SW^2 - 
    10944*cos^2*CW^2*MB^6*MC^6*s^2*SW^2 - 288*MB^5*MC^7*s^2*SW^2 - 
    288*cos^2*MB^5*MC^7*s^2*SW^2 - 6336*CW^2*MB^5*MC^7*s^2*SW^2 - 
    6336*cos^2*CW^2*MB^5*MC^7*s^2*SW^2 - 7056*MB^4*MC^8*s^2*SW^2 - 
    7056*cos^2*MB^4*MC^8*s^2*SW^2 + 2304*CW^2*MB^4*MC^8*s^2*SW^2 + 
    2304*cos^2*CW^2*MB^4*MC^8*s^2*SW^2 - 11328*MB^3*MC^9*s^2*SW^2 - 
    11328*cos^2*MB^3*MC^9*s^2*SW^2 + 7104*CW^2*MB^3*MC^9*s^2*SW^2 + 
    7104*cos^2*CW^2*MB^3*MC^9*s^2*SW^2 - 9072*MB^2*MC^10*s^2*SW^2 - 
    9072*cos^2*MB^2*MC^10*s^2*SW^2 + 5760*CW^2*MB^2*MC^10*s^2*SW^2 + 
    5760*cos^2*CW^2*MB^2*MC^10*s^2*SW^2 - 3744*MB*MC^11*s^2*SW^2 - 
    3744*cos^2*MB*MC^11*s^2*SW^2 + 2304*CW^2*MB*MC^11*s^2*SW^2 + 
    2304*cos^2*CW^2*MB*MC^11*s^2*SW^2 - 624*MC^12*s^2*SW^2 - 
    624*cos^2*MC^12*s^2*SW^2 + 384*CW^2*MC^12*s^2*SW^2 + 
    384*cos^2*CW^2*MC^12*s^2*SW^2 + 48*CW^2*MB^10*MZ^2*s^2*SW^2 + 
    48*cos^2*CW^2*MB^10*MZ^2*s^2*SW^2 + 192*CW^2*MB^9*MC*MZ^2*s^2*SW^2 + 
    192*cos^2*CW^2*MB^9*MC*MZ^2*s^2*SW^2 + 288*CW^2*MB^8*MC^2*MZ^2*s^2*SW^2 + 
    288*cos^2*CW^2*MB^8*MC^2*MZ^2*s^2*SW^2 + 48*CW^2*MB^7*MC^3*MZ^2*s^2*
     SW^2 + 48*cos^2*CW^2*MB^7*MC^3*MZ^2*s^2*SW^2 - 
    528*CW^2*MB^6*MC^4*MZ^2*s^2*SW^2 - 528*cos^2*CW^2*MB^6*MC^4*MZ^2*s^2*
     SW^2 - 864*CW^2*MB^5*MC^5*MZ^2*s^2*SW^2 - 864*cos^2*CW^2*MB^5*MC^5*MZ^2*
     s^2*SW^2 - 480*CW^2*MB^4*MC^6*MZ^2*s^2*SW^2 - 
    480*cos^2*CW^2*MB^4*MC^6*MZ^2*s^2*SW^2 + 240*CW^2*MB^3*MC^7*MZ^2*s^2*
     SW^2 + 240*cos^2*CW^2*MB^3*MC^7*MZ^2*s^2*SW^2 + 
    576*CW^2*MB^2*MC^8*MZ^2*s^2*SW^2 + 576*cos^2*CW^2*MB^2*MC^8*MZ^2*s^2*
     SW^2 + 384*CW^2*MB*MC^9*MZ^2*s^2*SW^2 + 384*cos^2*CW^2*MB*MC^9*MZ^2*s^2*
     SW^2 + 96*CW^2*MC^10*MZ^2*s^2*SW^2 + 96*cos^2*CW^2*MC^10*MZ^2*s^2*SW^2 + 
    96*MB^10*s^3*SW^2 + 96*cos^2*MB^10*s^3*SW^2 - 48*CW^2*MB^10*s^3*SW^2 - 
    48*cos^2*CW^2*MB^10*s^3*SW^2 + 456*MB^9*MC*s^3*SW^2 + 
    456*cos^2*MB^9*MC*s^3*SW^2 - 192*CW^2*MB^9*MC*s^3*SW^2 - 
    192*cos^2*CW^2*MB^9*MC*s^3*SW^2 + 828*MB^8*MC^2*s^3*SW^2 + 
    828*cos^2*MB^8*MC^2*s^3*SW^2 - 288*CW^2*MB^8*MC^2*s^3*SW^2 - 
    288*cos^2*CW^2*MB^8*MC^2*s^3*SW^2 + 672*MB^7*MC^3*s^3*SW^2 + 
    672*cos^2*MB^7*MC^3*s^3*SW^2 - 48*CW^2*MB^7*MC^3*s^3*SW^2 - 
    48*cos^2*CW^2*MB^7*MC^3*s^3*SW^2 + 276*MB^6*MC^4*s^3*SW^2 + 
    276*cos^2*MB^6*MC^4*s^3*SW^2 + 528*CW^2*MB^6*MC^4*s^3*SW^2 + 
    528*cos^2*CW^2*MB^6*MC^4*s^3*SW^2 + 144*MB^5*MC^5*s^3*SW^2 + 
    144*cos^2*MB^5*MC^5*s^3*SW^2 + 864*CW^2*MB^5*MC^5*s^3*SW^2 + 
    864*cos^2*CW^2*MB^5*MC^5*s^3*SW^2 + 300*MB^4*MC^6*s^3*SW^2 + 
    300*cos^2*MB^4*MC^6*s^3*SW^2 + 480*CW^2*MB^4*MC^6*s^3*SW^2 + 
    480*cos^2*CW^2*MB^4*MC^6*s^3*SW^2 + 768*MB^3*MC^7*s^3*SW^2 + 
    768*cos^2*MB^3*MC^7*s^3*SW^2 - 240*CW^2*MB^3*MC^7*s^3*SW^2 - 
    240*cos^2*CW^2*MB^3*MC^7*s^3*SW^2 + 972*MB^2*MC^8*s^3*SW^2 + 
    972*cos^2*MB^2*MC^8*s^3*SW^2 - 576*CW^2*MB^2*MC^8*s^3*SW^2 - 
    576*cos^2*CW^2*MB^2*MC^8*s^3*SW^2 + 552*MB*MC^9*s^3*SW^2 + 
    552*cos^2*MB*MC^9*s^3*SW^2 - 384*CW^2*MB*MC^9*s^3*SW^2 - 
    384*cos^2*CW^2*MB*MC^9*s^3*SW^2 + 120*MC^10*s^3*SW^2 + 
    120*cos^2*MC^10*s^3*SW^2 - 96*CW^2*MC^10*s^3*SW^2 - 
    96*cos^2*CW^2*MC^10*s^3*SW^2 + 36*MB^6*MC^2*s^4*SW^2 - 
    36*cos^2*MB^6*MC^2*s^4*SW^2 + 72*MB^4*MC^4*s^4*SW^2 - 
    72*cos^2*MB^4*MC^4*s^4*SW^2 + 36*MB^2*MC^6*s^4*SW^2 - 
    36*cos^2*MB^2*MC^6*s^4*SW^2 + 384*cos*CW^2*MB^12*MZ^2*Sqrt[s]*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 1920*cos*CW^2*MB^11*MC*MZ^2*
     Sqrt[s]*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
    3840*cos*CW^2*MB^10*MC^2*MZ^2*Sqrt[s]*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 3072*cos*CW^2*MB^9*MC^3*MZ^2*
     Sqrt[s]*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
    1536*cos*CW^2*MB^8*MC^4*MZ^2*Sqrt[s]*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 - 5376*cos*CW^2*MB^7*MC^5*MZ^2*Sqrt[s]*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 3840*cos*CW^2*MB^6*MC^6*MZ^2*
     Sqrt[s]*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
    768*cos*CW^2*MB^5*MC^7*MZ^2*Sqrt[s]*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 - 2688*cos*CW^2*MB^4*MC^8*MZ^2*Sqrt[s]*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 7296*cos*CW^2*MB^3*MC^9*MZ^2*
     Sqrt[s]*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
    7680*cos*CW^2*MB^2*MC^10*MZ^2*Sqrt[s]*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 3840*cos*CW^2*MB*MC^11*MZ^2*
     Sqrt[s]*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
    768*cos*CW^2*MC^12*MZ^2*Sqrt[s]*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 + 768*cos*MB^12*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
    384*cos*CW^2*MB^12*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
    3840*cos*MB^11*MC*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
    1920*cos*CW^2*MB^11*MC*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 + 7680*cos*MB^10*MC^2*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 - 3840*cos*CW^2*MB^10*MC^2*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 6720*cos*MB^9*MC^3*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 3072*cos*CW^2*MB^9*MC^3*
     s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
    192*cos*MB^8*MC^4*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
    1536*cos*CW^2*MB^8*MC^4*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 - 4992*cos*MB^7*MC^5*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 + 5376*cos*CW^2*MB^7*MC^5*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 1920*cos*MB^6*MC^6*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 3840*cos*CW^2*MB^6*MC^6*
     s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
    1920*cos*MB^5*MC^7*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
    768*cos*CW^2*MB^5*MC^7*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 - 1920*cos*MB^4*MC^8*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 + 2688*cos*CW^2*MB^4*MC^8*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 8832*cos*MB^3*MC^9*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 7296*cos*CW^2*MB^3*MC^9*
     s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
    9600*cos*MB^2*MC^10*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
    7680*cos*CW^2*MB^2*MC^10*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 - 4800*cos*MB*MC^11*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 + 3840*cos*CW^2*MB*MC^11*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 960*cos*MC^12*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 768*cos*CW^2*MC^12*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 96*cos*CW^2*MB^10*MZ^2*
     s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
    480*cos*CW^2*MB^9*MC*MZ^2*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 - 864*cos*CW^2*MB^8*MC^2*MZ^2*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 672*cos*CW^2*MB^7*MC^3*MZ^2*
     s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
    96*cos*CW^2*MB^6*MC^4*MZ^2*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 + 864*cos*CW^2*MB^5*MC^5*MZ^2*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 1248*cos*CW^2*MB^4*MC^6*MZ^2*
     s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
    1632*cos*CW^2*MB^3*MC^7*MZ^2*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 + 1728*cos*CW^2*MB^2*MC^8*MZ^2*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 960*cos*CW^2*MB*MC^9*MZ^2*
     s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
    192*cos*CW^2*MC^10*MZ^2*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 - 192*cos*MB^10*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
    96*cos*CW^2*MB^10*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
    960*cos*MB^9*MC*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
    480*cos*CW^2*MB^9*MC*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
    1728*cos*MB^8*MC^2*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
    864*cos*CW^2*MB^8*MC^2*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 - 1488*cos*MB^7*MC^3*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 + 672*cos*CW^2*MB^7*MC^3*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 528*cos*MB^6*MC^4*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 96*cos*CW^2*MB^6*MC^4*
     s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
    432*cos*MB^5*MC^5*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
    864*cos*CW^2*MB^5*MC^5*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 + 1200*cos*MB^4*MC^6*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 - 1248*cos*CW^2*MB^4*MC^6*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 1968*cos*MB^3*MC^7*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 1632*cos*CW^2*MB^3*MC^7*
     s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
    2160*cos*MB^2*MC^8*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
    1728*cos*CW^2*MB^2*MC^8*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 + 1200*cos*MB*MC^9*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 - 960*cos*CW^2*MB*MC^9*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
     SW^2 + 240*cos*MC^10*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
    192*cos*CW^2*MC^10*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
    512*CW^4*GammaZ^2*MB^12*MZ^2*SW^4 + 512*cos^2*CW^4*GammaZ^2*MB^12*MZ^2*
     SW^4 + 3072*CW^4*GammaZ^2*MB^11*MC*MZ^2*SW^4 + 
    3072*cos^2*CW^4*GammaZ^2*MB^11*MC*MZ^2*SW^4 + 7680*CW^4*GammaZ^2*MB^10*
     MC^2*MZ^2*SW^4 + 7680*cos^2*CW^4*GammaZ^2*MB^10*MC^2*MZ^2*SW^4 + 
    8192*CW^4*GammaZ^2*MB^9*MC^3*MZ^2*SW^4 + 8192*cos^2*CW^4*GammaZ^2*MB^9*
     MC^3*MZ^2*SW^4 - 4608*CW^4*GammaZ^2*MB^8*MC^4*MZ^2*SW^4 - 
    4608*cos^2*CW^4*GammaZ^2*MB^8*MC^4*MZ^2*SW^4 - 
    27648*CW^4*GammaZ^2*MB^7*MC^5*MZ^2*SW^4 - 27648*cos^2*CW^4*GammaZ^2*MB^7*
     MC^5*MZ^2*SW^4 - 38400*CW^4*GammaZ^2*MB^6*MC^6*MZ^2*SW^4 - 
    38400*cos^2*CW^4*GammaZ^2*MB^6*MC^6*MZ^2*SW^4 - 
    18432*CW^4*GammaZ^2*MB^5*MC^7*MZ^2*SW^4 - 18432*cos^2*CW^4*GammaZ^2*MB^5*
     MC^7*MZ^2*SW^4 + 18432*CW^4*GammaZ^2*MB^4*MC^8*MZ^2*SW^4 + 
    18432*cos^2*CW^4*GammaZ^2*MB^4*MC^8*MZ^2*SW^4 + 
    38912*CW^4*GammaZ^2*MB^3*MC^9*MZ^2*SW^4 + 38912*cos^2*CW^4*GammaZ^2*MB^3*
     MC^9*MZ^2*SW^4 + 30720*CW^4*GammaZ^2*MB^2*MC^10*MZ^2*SW^4 + 
    30720*cos^2*CW^4*GammaZ^2*MB^2*MC^10*MZ^2*SW^4 + 
    12288*CW^4*GammaZ^2*MB*MC^11*MZ^2*SW^4 + 12288*cos^2*CW^4*GammaZ^2*MB*
     MC^11*MZ^2*SW^4 + 2048*CW^4*GammaZ^2*MC^12*MZ^2*SW^4 + 
    2048*cos^2*CW^4*GammaZ^2*MC^12*MZ^2*SW^4 + 512*CW^4*MB^12*MZ^4*SW^4 + 
    512*cos^2*CW^4*MB^12*MZ^4*SW^4 + 3072*CW^4*MB^11*MC*MZ^4*SW^4 + 
    3072*cos^2*CW^4*MB^11*MC*MZ^4*SW^4 + 7680*CW^4*MB^10*MC^2*MZ^4*SW^4 + 
    7680*cos^2*CW^4*MB^10*MC^2*MZ^4*SW^4 + 8192*CW^4*MB^9*MC^3*MZ^4*SW^4 + 
    8192*cos^2*CW^4*MB^9*MC^3*MZ^4*SW^4 - 4608*CW^4*MB^8*MC^4*MZ^4*SW^4 - 
    4608*cos^2*CW^4*MB^8*MC^4*MZ^4*SW^4 - 27648*CW^4*MB^7*MC^5*MZ^4*SW^4 - 
    27648*cos^2*CW^4*MB^7*MC^5*MZ^4*SW^4 - 38400*CW^4*MB^6*MC^6*MZ^4*SW^4 - 
    38400*cos^2*CW^4*MB^6*MC^6*MZ^4*SW^4 - 18432*CW^4*MB^5*MC^7*MZ^4*SW^4 - 
    18432*cos^2*CW^4*MB^5*MC^7*MZ^4*SW^4 + 18432*CW^4*MB^4*MC^8*MZ^4*SW^4 + 
    18432*cos^2*CW^4*MB^4*MC^8*MZ^4*SW^4 + 38912*CW^4*MB^3*MC^9*MZ^4*SW^4 + 
    38912*cos^2*CW^4*MB^3*MC^9*MZ^4*SW^4 + 30720*CW^4*MB^2*MC^10*MZ^4*SW^4 + 
    30720*cos^2*CW^4*MB^2*MC^10*MZ^4*SW^4 + 12288*CW^4*MB*MC^11*MZ^4*SW^4 + 
    12288*cos^2*CW^4*MB*MC^11*MZ^4*SW^4 + 2048*CW^4*MC^12*MZ^4*SW^4 + 
    2048*cos^2*CW^4*MC^12*MZ^4*SW^4 - 1152*MB^14*s*SW^4 - 
    1152*cos^2*MB^14*s*SW^4 - 6912*MB^13*MC*s*SW^4 - 
    6912*cos^2*MB^13*MC*s*SW^4 - 17280*MB^12*MC^2*s*SW^4 - 
    17280*cos^2*MB^12*MC^2*s*SW^4 - 23040*MB^11*MC^3*s*SW^4 - 
    23040*cos^2*MB^11*MC^3*s*SW^4 - 19584*MB^10*MC^4*s*SW^4 - 
    19584*cos^2*MB^10*MC^4*s*SW^4 - 20736*MB^9*MC^5*s*SW^4 - 
    20736*cos^2*MB^9*MC^5*s*SW^4 - 35712*MB^8*MC^6*s*SW^4 - 
    35712*cos^2*MB^8*MC^6*s*SW^4 - 46080*MB^7*MC^7*s*SW^4 - 
    46080*cos^2*MB^7*MC^7*s*SW^4 - 35712*MB^6*MC^8*s*SW^4 - 
    35712*cos^2*MB^6*MC^8*s*SW^4 - 20736*MB^5*MC^9*s*SW^4 - 
    20736*cos^2*MB^5*MC^9*s*SW^4 - 19584*MB^4*MC^10*s*SW^4 - 
    19584*cos^2*MB^4*MC^10*s*SW^4 - 23040*MB^3*MC^11*s*SW^4 - 
    23040*cos^2*MB^3*MC^11*s*SW^4 - 17280*MB^2*MC^12*s*SW^4 - 
    17280*cos^2*MB^2*MC^12*s*SW^4 - 6912*MB*MC^13*s*SW^4 - 
    6912*cos^2*MB*MC^13*s*SW^4 - 1152*MC^14*s*SW^4 - 
    1152*cos^2*MC^14*s*SW^4 - 128*CW^4*GammaZ^2*MB^10*MZ^2*s*SW^4 - 
    128*cos^2*CW^4*GammaZ^2*MB^10*MZ^2*s*SW^4 + 1024*CW^2*MB^12*MZ^2*s*SW^4 + 
    1024*cos^2*CW^2*MB^12*MZ^2*s*SW^4 - 1024*CW^4*MB^12*MZ^2*s*SW^4 - 
    1024*cos^2*CW^4*MB^12*MZ^2*s*SW^4 - 512*CW^4*GammaZ^2*MB^9*MC*MZ^2*s*
     SW^4 - 512*cos^2*CW^4*GammaZ^2*MB^9*MC*MZ^2*s*SW^4 + 
    6144*CW^2*MB^11*MC*MZ^2*s*SW^4 + 6144*cos^2*CW^2*MB^11*MC*MZ^2*s*SW^4 - 
    6144*CW^4*MB^11*MC*MZ^2*s*SW^4 - 6144*cos^2*CW^4*MB^11*MC*MZ^2*s*SW^4 - 
    768*CW^4*GammaZ^2*MB^8*MC^2*MZ^2*s*SW^4 - 768*cos^2*CW^4*GammaZ^2*MB^8*
     MC^2*MZ^2*s*SW^4 + 15360*CW^2*MB^10*MC^2*MZ^2*s*SW^4 + 
    15360*cos^2*CW^2*MB^10*MC^2*MZ^2*s*SW^4 - 15360*CW^4*MB^10*MC^2*MZ^2*s*
     SW^4 - 15360*cos^2*CW^4*MB^10*MC^2*MZ^2*s*SW^4 + 
    17152*CW^2*MB^9*MC^3*MZ^2*s*SW^4 + 17152*cos^2*CW^2*MB^9*MC^3*MZ^2*s*
     SW^4 - 16384*CW^4*MB^9*MC^3*MZ^2*s*SW^4 - 16384*cos^2*CW^4*MB^9*MC^3*
     MZ^2*s*SW^4 + 1920*CW^4*GammaZ^2*MB^6*MC^4*MZ^2*s*SW^4 + 
    1920*cos^2*CW^4*GammaZ^2*MB^6*MC^4*MZ^2*s*SW^4 - 
    4608*CW^2*MB^8*MC^4*MZ^2*s*SW^4 - 4608*cos^2*CW^2*MB^8*MC^4*MZ^2*s*SW^4 + 
    9216*CW^4*MB^8*MC^4*MZ^2*s*SW^4 + 9216*cos^2*CW^4*MB^8*MC^4*MZ^2*s*SW^4 + 
    3072*CW^4*GammaZ^2*MB^5*MC^5*MZ^2*s*SW^4 + 3072*cos^2*CW^4*GammaZ^2*MB^5*
     MC^5*MZ^2*s*SW^4 - 43776*CW^2*MB^7*MC^5*MZ^2*s*SW^4 - 
    43776*cos^2*CW^2*MB^7*MC^5*MZ^2*s*SW^4 + 55296*CW^4*MB^7*MC^5*MZ^2*s*
     SW^4 + 55296*cos^2*CW^4*MB^7*MC^5*MZ^2*s*SW^4 + 
    1536*CW^4*GammaZ^2*MB^4*MC^6*MZ^2*s*SW^4 + 1536*cos^2*CW^4*GammaZ^2*MB^4*
     MC^6*MZ^2*s*SW^4 - 62976*CW^2*MB^6*MC^6*MZ^2*s*SW^4 - 
    62976*cos^2*CW^2*MB^6*MC^6*MZ^2*s*SW^4 + 76800*CW^4*MB^6*MC^6*MZ^2*s*
     SW^4 + 76800*cos^2*CW^4*MB^6*MC^6*MZ^2*s*SW^4 - 
    1536*CW^4*GammaZ^2*MB^3*MC^7*MZ^2*s*SW^4 - 1536*cos^2*CW^4*GammaZ^2*MB^3*
     MC^7*MZ^2*s*SW^4 - 34560*CW^2*MB^5*MC^7*MZ^2*s*SW^4 - 
    34560*cos^2*CW^2*MB^5*MC^7*MZ^2*s*SW^4 + 36864*CW^4*MB^5*MC^7*MZ^2*s*
     SW^4 + 36864*cos^2*CW^4*MB^5*MC^7*MZ^2*s*SW^4 - 
    3072*CW^4*GammaZ^2*MB^2*MC^8*MZ^2*s*SW^4 - 3072*cos^2*CW^4*GammaZ^2*MB^2*
     MC^8*MZ^2*s*SW^4 + 18432*CW^2*MB^4*MC^8*MZ^2*s*SW^4 + 
    18432*cos^2*CW^2*MB^4*MC^8*MZ^2*s*SW^4 - 36864*CW^4*MB^4*MC^8*MZ^2*s*
     SW^4 - 36864*cos^2*CW^4*MB^4*MC^8*MZ^2*s*SW^4 - 
    2048*CW^4*GammaZ^2*MB*MC^9*MZ^2*s*SW^4 - 2048*cos^2*CW^4*GammaZ^2*MB*MC^9*
     MZ^2*s*SW^4 + 47872*CW^2*MB^3*MC^9*MZ^2*s*SW^4 + 
    47872*cos^2*CW^2*MB^3*MC^9*MZ^2*s*SW^4 - 77824*CW^4*MB^3*MC^9*MZ^2*s*
     SW^4 - 77824*cos^2*CW^4*MB^3*MC^9*MZ^2*s*SW^4 - 
    512*CW^4*GammaZ^2*MC^10*MZ^2*s*SW^4 - 512*cos^2*CW^4*GammaZ^2*MC^10*MZ^2*
     s*SW^4 + 38400*CW^2*MB^2*MC^10*MZ^2*s*SW^4 + 38400*cos^2*CW^2*MB^2*MC^10*
     MZ^2*s*SW^4 - 61440*CW^4*MB^2*MC^10*MZ^2*s*SW^4 - 
    61440*cos^2*CW^4*MB^2*MC^10*MZ^2*s*SW^4 + 15360*CW^2*MB*MC^11*MZ^2*s*
     SW^4 + 15360*cos^2*CW^2*MB*MC^11*MZ^2*s*SW^4 - 
    24576*CW^4*MB*MC^11*MZ^2*s*SW^4 - 24576*cos^2*CW^4*MB*MC^11*MZ^2*s*SW^4 + 
    2560*CW^2*MC^12*MZ^2*s*SW^4 + 2560*cos^2*CW^2*MC^12*MZ^2*s*SW^4 - 
    4096*CW^4*MC^12*MZ^2*s*SW^4 - 4096*cos^2*CW^4*MC^12*MZ^2*s*SW^4 - 
    128*CW^4*MB^10*MZ^4*s*SW^4 - 128*cos^2*CW^4*MB^10*MZ^4*s*SW^4 - 
    512*CW^4*MB^9*MC*MZ^4*s*SW^4 - 512*cos^2*CW^4*MB^9*MC*MZ^4*s*SW^4 - 
    768*CW^4*MB^8*MC^2*MZ^4*s*SW^4 - 768*cos^2*CW^4*MB^8*MC^2*MZ^4*s*SW^4 + 
    1920*CW^4*MB^6*MC^4*MZ^4*s*SW^4 + 1920*cos^2*CW^4*MB^6*MC^4*MZ^4*s*SW^4 + 
    3072*CW^4*MB^5*MC^5*MZ^4*s*SW^4 + 3072*cos^2*CW^4*MB^5*MC^5*MZ^4*s*SW^4 + 
    1536*CW^4*MB^4*MC^6*MZ^4*s*SW^4 + 1536*cos^2*CW^4*MB^4*MC^6*MZ^4*s*SW^4 - 
    1536*CW^4*MB^3*MC^7*MZ^4*s*SW^4 - 1536*cos^2*CW^4*MB^3*MC^7*MZ^4*s*SW^4 - 
    3072*CW^4*MB^2*MC^8*MZ^4*s*SW^4 - 3072*cos^2*CW^4*MB^2*MC^8*MZ^4*s*SW^4 - 
    2048*CW^4*MB*MC^9*MZ^4*s*SW^4 - 2048*cos^2*CW^4*MB*MC^9*MZ^4*s*SW^4 - 
    512*CW^4*MC^10*MZ^4*s*SW^4 - 512*cos^2*CW^4*MC^10*MZ^4*s*SW^4 + 
    1312*MB^12*s^2*SW^4 + 1312*cos^2*MB^12*s^2*SW^4 - 
    1024*CW^2*MB^12*s^2*SW^4 - 1024*cos^2*CW^2*MB^12*s^2*SW^4 + 
    512*CW^4*MB^12*s^2*SW^4 + 512*cos^2*CW^4*MB^12*s^2*SW^4 + 
    7872*MB^11*MC*s^2*SW^4 + 7872*cos^2*MB^11*MC*s^2*SW^4 - 
    6144*CW^2*MB^11*MC*s^2*SW^4 - 6144*cos^2*CW^2*MB^11*MC*s^2*SW^4 + 
    3072*CW^4*MB^11*MC*s^2*SW^4 + 3072*cos^2*CW^4*MB^11*MC*s^2*SW^4 + 
    19104*MB^10*MC^2*s^2*SW^4 + 19104*cos^2*MB^10*MC^2*s^2*SW^4 - 
    15360*CW^2*MB^10*MC^2*s^2*SW^4 - 15360*cos^2*CW^2*MB^10*MC^2*s^2*SW^4 + 
    7680*CW^4*MB^10*MC^2*s^2*SW^4 + 7680*cos^2*CW^4*MB^10*MC^2*s^2*SW^4 + 
    23104*MB^9*MC^3*s^2*SW^4 + 23104*cos^2*MB^9*MC^3*s^2*SW^4 - 
    17152*CW^2*MB^9*MC^3*s^2*SW^4 - 17152*cos^2*CW^2*MB^9*MC^3*s^2*SW^4 + 
    8192*CW^4*MB^9*MC^3*s^2*SW^4 + 8192*cos^2*CW^4*MB^9*MC^3*s^2*SW^4 + 
    10080*MB^8*MC^4*s^2*SW^4 + 10080*cos^2*MB^8*MC^4*s^2*SW^4 + 
    4608*CW^2*MB^8*MC^4*s^2*SW^4 + 4608*cos^2*CW^2*MB^8*MC^4*s^2*SW^4 - 
    4608*CW^4*MB^8*MC^4*s^2*SW^4 - 4608*cos^2*CW^4*MB^8*MC^4*s^2*SW^4 - 
    11520*MB^7*MC^5*s^2*SW^4 - 11520*cos^2*MB^7*MC^5*s^2*SW^4 + 
    43776*CW^2*MB^7*MC^5*s^2*SW^4 + 43776*cos^2*CW^2*MB^7*MC^5*s^2*SW^4 - 
    27648*CW^4*MB^7*MC^5*s^2*SW^4 - 27648*cos^2*CW^4*MB^7*MC^5*s^2*SW^4 - 
    21504*MB^6*MC^6*s^2*SW^4 - 21504*cos^2*MB^6*MC^6*s^2*SW^4 + 
    62976*CW^2*MB^6*MC^6*s^2*SW^4 + 62976*cos^2*CW^2*MB^6*MC^6*s^2*SW^4 - 
    38400*CW^4*MB^6*MC^6*s^2*SW^4 - 38400*cos^2*CW^4*MB^6*MC^6*s^2*SW^4 - 
    8064*MB^5*MC^7*s^2*SW^4 - 8064*cos^2*MB^5*MC^7*s^2*SW^4 + 
    34560*CW^2*MB^5*MC^7*s^2*SW^4 + 34560*cos^2*CW^2*MB^5*MC^7*s^2*SW^4 - 
    18432*CW^4*MB^5*MC^7*s^2*SW^4 - 18432*cos^2*CW^4*MB^5*MC^7*s^2*SW^4 + 
    18720*MB^4*MC^8*s^2*SW^4 + 18720*cos^2*MB^4*MC^8*s^2*SW^4 - 
    18432*CW^2*MB^4*MC^8*s^2*SW^4 - 18432*cos^2*CW^2*MB^4*MC^8*s^2*SW^4 + 
    18432*CW^4*MB^4*MC^8*s^2*SW^4 + 18432*cos^2*CW^4*MB^4*MC^8*s^2*SW^4 + 
    34624*MB^3*MC^9*s^2*SW^4 + 34624*cos^2*MB^3*MC^9*s^2*SW^4 - 
    47872*CW^2*MB^3*MC^9*s^2*SW^4 - 47872*cos^2*CW^2*MB^3*MC^9*s^2*SW^4 + 
    38912*CW^4*MB^3*MC^9*s^2*SW^4 + 38912*cos^2*CW^4*MB^3*MC^9*s^2*SW^4 + 
    27744*MB^2*MC^10*s^2*SW^4 + 27744*cos^2*MB^2*MC^10*s^2*SW^4 - 
    38400*CW^2*MB^2*MC^10*s^2*SW^4 - 38400*cos^2*CW^2*MB^2*MC^10*s^2*SW^4 + 
    30720*CW^4*MB^2*MC^10*s^2*SW^4 + 30720*cos^2*CW^4*MB^2*MC^10*s^2*SW^4 + 
    11328*MB*MC^11*s^2*SW^4 + 11328*cos^2*MB*MC^11*s^2*SW^4 - 
    15360*CW^2*MB*MC^11*s^2*SW^4 - 15360*cos^2*CW^2*MB*MC^11*s^2*SW^4 + 
    12288*CW^4*MB*MC^11*s^2*SW^4 + 12288*cos^2*CW^4*MB*MC^11*s^2*SW^4 + 
    1888*MC^12*s^2*SW^4 + 1888*cos^2*MC^12*s^2*SW^4 - 
    2560*CW^2*MC^12*s^2*SW^4 - 2560*cos^2*CW^2*MC^12*s^2*SW^4 + 
    2048*CW^4*MC^12*s^2*SW^4 + 2048*cos^2*CW^4*MC^12*s^2*SW^4 - 
    256*CW^2*MB^10*MZ^2*s^2*SW^4 - 256*cos^2*CW^2*MB^10*MZ^2*s^2*SW^4 + 
    256*CW^4*MB^10*MZ^2*s^2*SW^4 + 256*cos^2*CW^4*MB^10*MZ^2*s^2*SW^4 - 
    1024*CW^2*MB^9*MC*MZ^2*s^2*SW^4 - 1024*cos^2*CW^2*MB^9*MC*MZ^2*s^2*SW^4 + 
    1024*CW^4*MB^9*MC*MZ^2*s^2*SW^4 + 1024*cos^2*CW^4*MB^9*MC*MZ^2*s^2*SW^4 - 
    1536*CW^2*MB^8*MC^2*MZ^2*s^2*SW^4 - 1536*cos^2*CW^2*MB^8*MC^2*MZ^2*s^2*
     SW^4 + 1536*CW^4*MB^8*MC^2*MZ^2*s^2*SW^4 + 1536*cos^2*CW^4*MB^8*MC^2*
     MZ^2*s^2*SW^4 - 192*CW^2*MB^7*MC^3*MZ^2*s^2*SW^4 - 
    192*cos^2*CW^2*MB^7*MC^3*MZ^2*s^2*SW^4 + 3072*CW^2*MB^6*MC^4*MZ^2*s^2*
     SW^4 + 3072*cos^2*CW^2*MB^6*MC^4*MZ^2*s^2*SW^4 - 
    3840*CW^4*MB^6*MC^4*MZ^2*s^2*SW^4 - 3840*cos^2*CW^4*MB^6*MC^4*MZ^2*s^2*
     SW^4 + 4992*CW^2*MB^5*MC^5*MZ^2*s^2*SW^4 + 4992*cos^2*CW^2*MB^5*MC^5*
     MZ^2*s^2*SW^4 - 6144*CW^4*MB^5*MC^5*MZ^2*s^2*SW^4 - 
    6144*cos^2*CW^4*MB^5*MC^5*MZ^2*s^2*SW^4 + 2688*CW^2*MB^4*MC^6*MZ^2*s^2*
     SW^4 + 2688*cos^2*CW^2*MB^4*MC^6*MZ^2*s^2*SW^4 - 
    3072*CW^4*MB^4*MC^6*MZ^2*s^2*SW^4 - 3072*cos^2*CW^4*MB^4*MC^6*MZ^2*s^2*
     SW^4 - 1728*CW^2*MB^3*MC^7*MZ^2*s^2*SW^4 - 1728*cos^2*CW^2*MB^3*MC^7*
     MZ^2*s^2*SW^4 + 3072*CW^4*MB^3*MC^7*MZ^2*s^2*SW^4 + 
    3072*cos^2*CW^4*MB^3*MC^7*MZ^2*s^2*SW^4 - 3840*CW^2*MB^2*MC^8*MZ^2*s^2*
     SW^4 - 3840*cos^2*CW^2*MB^2*MC^8*MZ^2*s^2*SW^4 + 
    6144*CW^4*MB^2*MC^8*MZ^2*s^2*SW^4 + 6144*cos^2*CW^4*MB^2*MC^8*MZ^2*s^2*
     SW^4 - 2560*CW^2*MB*MC^9*MZ^2*s^2*SW^4 - 2560*cos^2*CW^2*MB*MC^9*MZ^2*
     s^2*SW^4 + 4096*CW^4*MB*MC^9*MZ^2*s^2*SW^4 + 4096*cos^2*CW^4*MB*MC^9*
     MZ^2*s^2*SW^4 - 640*CW^2*MC^10*MZ^2*s^2*SW^4 - 
    640*cos^2*CW^2*MC^10*MZ^2*s^2*SW^4 + 1024*CW^4*MC^10*MZ^2*s^2*SW^4 + 
    1024*cos^2*CW^4*MC^10*MZ^2*s^2*SW^4 - 256*MB^10*s^3*SW^4 - 
    256*cos^2*MB^10*s^3*SW^4 + 256*CW^2*MB^10*s^3*SW^4 + 
    256*cos^2*CW^2*MB^10*s^3*SW^4 - 128*CW^4*MB^10*s^3*SW^4 - 
    128*cos^2*CW^4*MB^10*s^3*SW^4 - 1168*MB^9*MC*s^3*SW^4 - 
    1168*cos^2*MB^9*MC*s^3*SW^4 + 1024*CW^2*MB^9*MC*s^3*SW^4 + 
    1024*cos^2*CW^2*MB^9*MC*s^3*SW^4 - 512*CW^4*MB^9*MC*s^3*SW^4 - 
    512*cos^2*CW^4*MB^9*MC*s^3*SW^4 - 2040*MB^8*MC^2*s^3*SW^4 - 
    2040*cos^2*MB^8*MC^2*s^3*SW^4 + 1536*CW^2*MB^8*MC^2*s^3*SW^4 + 
    1536*cos^2*CW^2*MB^8*MC^2*s^3*SW^4 - 768*CW^4*MB^8*MC^2*s^3*SW^4 - 
    768*cos^2*CW^4*MB^8*MC^2*s^3*SW^4 - 1392*MB^7*MC^3*s^3*SW^4 - 
    1392*cos^2*MB^7*MC^3*s^3*SW^4 + 192*CW^2*MB^7*MC^3*s^3*SW^4 + 
    192*cos^2*CW^2*MB^7*MC^3*s^3*SW^4 + 216*MB^6*MC^4*s^3*SW^4 + 
    216*cos^2*MB^6*MC^4*s^3*SW^4 - 3072*CW^2*MB^6*MC^4*s^3*SW^4 - 
    3072*cos^2*CW^2*MB^6*MC^4*s^3*SW^4 + 1920*CW^4*MB^6*MC^4*s^3*SW^4 + 
    1920*cos^2*CW^4*MB^6*MC^4*s^3*SW^4 + 960*MB^5*MC^5*s^3*SW^4 + 
    960*cos^2*MB^5*MC^5*s^3*SW^4 - 4992*CW^2*MB^5*MC^5*s^3*SW^4 - 
    4992*cos^2*CW^2*MB^5*MC^5*s^3*SW^4 + 3072*CW^4*MB^5*MC^5*s^3*SW^4 + 
    3072*cos^2*CW^4*MB^5*MC^5*s^3*SW^4 + 72*MB^4*MC^6*s^3*SW^4 + 
    72*cos^2*MB^4*MC^6*s^3*SW^4 - 2688*CW^2*MB^4*MC^6*s^3*SW^4 - 
    2688*cos^2*CW^2*MB^4*MC^6*s^3*SW^4 + 1536*CW^4*MB^4*MC^6*s^3*SW^4 + 
    1536*cos^2*CW^4*MB^4*MC^6*s^3*SW^4 - 1968*MB^3*MC^7*s^3*SW^4 - 
    1968*cos^2*MB^3*MC^7*s^3*SW^4 + 1728*CW^2*MB^3*MC^7*s^3*SW^4 + 
    1728*cos^2*CW^2*MB^3*MC^7*s^3*SW^4 - 1536*CW^4*MB^3*MC^7*s^3*SW^4 - 
    1536*cos^2*CW^4*MB^3*MC^7*s^3*SW^4 - 2904*MB^2*MC^8*s^3*SW^4 - 
    2904*cos^2*MB^2*MC^8*s^3*SW^4 + 3840*CW^2*MB^2*MC^8*s^3*SW^4 + 
    3840*cos^2*CW^2*MB^2*MC^8*s^3*SW^4 - 3072*CW^4*MB^2*MC^8*s^3*SW^4 - 
    3072*cos^2*CW^4*MB^2*MC^8*s^3*SW^4 - 1744*MB*MC^9*s^3*SW^4 - 
    1744*cos^2*MB*MC^9*s^3*SW^4 + 2560*CW^2*MB*MC^9*s^3*SW^4 + 
    2560*cos^2*CW^2*MB*MC^9*s^3*SW^4 - 2048*CW^4*MB*MC^9*s^3*SW^4 - 
    2048*cos^2*CW^4*MB*MC^9*s^3*SW^4 - 400*MC^10*s^3*SW^4 - 
    400*cos^2*MC^10*s^3*SW^4 + 640*CW^2*MC^10*s^3*SW^4 + 
    640*cos^2*CW^2*MC^10*s^3*SW^4 - 512*CW^4*MC^10*s^3*SW^4 - 
    512*cos^2*CW^4*MC^10*s^3*SW^4 - 72*MB^6*MC^2*s^4*SW^4 + 
    72*cos^2*MB^6*MC^2*s^4*SW^4 - 144*MB^4*MC^4*s^4*SW^4 + 
    144*cos^2*MB^4*MC^4*s^4*SW^4 - 72*MB^2*MC^6*s^4*SW^4 + 
    72*cos^2*MB^2*MC^6*s^4*SW^4 - 768*cos*MB^12*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 3840*cos*MB^11*MC*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 7680*cos*MB^10*MC^2*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 6144*cos*MB^9*MC^3*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 3072*cos*MB^8*MC^4*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 10752*cos*MB^7*MC^5*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 7680*cos*MB^6*MC^6*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 1536*cos*MB^5*MC^7*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 5376*cos*MB^4*MC^8*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 14592*cos*MB^3*MC^9*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 15360*cos*MB^2*MC^10*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 7680*cos*MB*MC^11*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 1536*cos*MC^12*s^(3/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 192*cos*MB^10*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 960*cos*MB^9*MC*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 1728*cos*MB^8*MC^2*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 1344*cos*MB^7*MC^3*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 192*cos*MB^6*MC^4*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 1728*cos*MB^5*MC^5*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 2496*cos*MB^4*MC^6*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 3264*cos*MB^3*MC^7*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 3456*cos*MB^2*MC^8*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 1920*cos*MB*MC^9*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 384*cos*MC^10*s^(5/2)*
     Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 1024*CW^2*MB^12*MZ^2*s*
     SW^6 - 1024*cos^2*CW^2*MB^12*MZ^2*s*SW^6 - 6144*CW^2*MB^11*MC*MZ^2*s*
     SW^6 - 6144*cos^2*CW^2*MB^11*MC*MZ^2*s*SW^6 - 
    15360*CW^2*MB^10*MC^2*MZ^2*s*SW^6 - 15360*cos^2*CW^2*MB^10*MC^2*MZ^2*s*
     SW^6 - 16384*CW^2*MB^9*MC^3*MZ^2*s*SW^6 - 16384*cos^2*CW^2*MB^9*MC^3*
     MZ^2*s*SW^6 + 9216*CW^2*MB^8*MC^4*MZ^2*s*SW^6 + 
    9216*cos^2*CW^2*MB^8*MC^4*MZ^2*s*SW^6 + 55296*CW^2*MB^7*MC^5*MZ^2*s*
     SW^6 + 55296*cos^2*CW^2*MB^7*MC^5*MZ^2*s*SW^6 + 
    76800*CW^2*MB^6*MC^6*MZ^2*s*SW^6 + 76800*cos^2*CW^2*MB^6*MC^6*MZ^2*s*
     SW^6 + 36864*CW^2*MB^5*MC^7*MZ^2*s*SW^6 + 36864*cos^2*CW^2*MB^5*MC^7*
     MZ^2*s*SW^6 - 36864*CW^2*MB^4*MC^8*MZ^2*s*SW^6 - 
    36864*cos^2*CW^2*MB^4*MC^8*MZ^2*s*SW^6 - 77824*CW^2*MB^3*MC^9*MZ^2*s*
     SW^6 - 77824*cos^2*CW^2*MB^3*MC^9*MZ^2*s*SW^6 - 
    61440*CW^2*MB^2*MC^10*MZ^2*s*SW^6 - 61440*cos^2*CW^2*MB^2*MC^10*MZ^2*s*
     SW^6 - 24576*CW^2*MB*MC^11*MZ^2*s*SW^6 - 24576*cos^2*CW^2*MB*MC^11*MZ^2*
     s*SW^6 - 4096*CW^2*MC^12*MZ^2*s*SW^6 - 4096*cos^2*CW^2*MC^12*MZ^2*s*
     SW^6 - 1024*MB^12*s^2*SW^6 - 1024*cos^2*MB^12*s^2*SW^6 + 
    1024*CW^2*MB^12*s^2*SW^6 + 1024*cos^2*CW^2*MB^12*s^2*SW^6 - 
    6144*MB^11*MC*s^2*SW^6 - 6144*cos^2*MB^11*MC*s^2*SW^6 + 
    6144*CW^2*MB^11*MC*s^2*SW^6 + 6144*cos^2*CW^2*MB^11*MC*s^2*SW^6 - 
    15360*MB^10*MC^2*s^2*SW^6 - 15360*cos^2*MB^10*MC^2*s^2*SW^6 + 
    15360*CW^2*MB^10*MC^2*s^2*SW^6 + 15360*cos^2*CW^2*MB^10*MC^2*s^2*SW^6 - 
    17152*MB^9*MC^3*s^2*SW^6 - 17152*cos^2*MB^9*MC^3*s^2*SW^6 + 
    16384*CW^2*MB^9*MC^3*s^2*SW^6 + 16384*cos^2*CW^2*MB^9*MC^3*s^2*SW^6 + 
    4608*MB^8*MC^4*s^2*SW^6 + 4608*cos^2*MB^8*MC^4*s^2*SW^6 - 
    9216*CW^2*MB^8*MC^4*s^2*SW^6 - 9216*cos^2*CW^2*MB^8*MC^4*s^2*SW^6 + 
    43776*MB^7*MC^5*s^2*SW^6 + 43776*cos^2*MB^7*MC^5*s^2*SW^6 - 
    55296*CW^2*MB^7*MC^5*s^2*SW^6 - 55296*cos^2*CW^2*MB^7*MC^5*s^2*SW^6 + 
    62976*MB^6*MC^6*s^2*SW^6 + 62976*cos^2*MB^6*MC^6*s^2*SW^6 - 
    76800*CW^2*MB^6*MC^6*s^2*SW^6 - 76800*cos^2*CW^2*MB^6*MC^6*s^2*SW^6 + 
    34560*MB^5*MC^7*s^2*SW^6 + 34560*cos^2*MB^5*MC^7*s^2*SW^6 - 
    36864*CW^2*MB^5*MC^7*s^2*SW^6 - 36864*cos^2*CW^2*MB^5*MC^7*s^2*SW^6 - 
    18432*MB^4*MC^8*s^2*SW^6 - 18432*cos^2*MB^4*MC^8*s^2*SW^6 + 
    36864*CW^2*MB^4*MC^8*s^2*SW^6 + 36864*cos^2*CW^2*MB^4*MC^8*s^2*SW^6 - 
    47872*MB^3*MC^9*s^2*SW^6 - 47872*cos^2*MB^3*MC^9*s^2*SW^6 + 
    77824*CW^2*MB^3*MC^9*s^2*SW^6 + 77824*cos^2*CW^2*MB^3*MC^9*s^2*SW^6 - 
    38400*MB^2*MC^10*s^2*SW^6 - 38400*cos^2*MB^2*MC^10*s^2*SW^6 + 
    61440*CW^2*MB^2*MC^10*s^2*SW^6 + 61440*cos^2*CW^2*MB^2*MC^10*s^2*SW^6 - 
    15360*MB*MC^11*s^2*SW^6 - 15360*cos^2*MB*MC^11*s^2*SW^6 + 
    24576*CW^2*MB*MC^11*s^2*SW^6 + 24576*cos^2*CW^2*MB*MC^11*s^2*SW^6 - 
    2560*MC^12*s^2*SW^6 - 2560*cos^2*MC^12*s^2*SW^6 + 
    4096*CW^2*MC^12*s^2*SW^6 + 4096*cos^2*CW^2*MC^12*s^2*SW^6 + 
    256*CW^2*MB^10*MZ^2*s^2*SW^6 + 256*cos^2*CW^2*MB^10*MZ^2*s^2*SW^6 + 
    1024*CW^2*MB^9*MC*MZ^2*s^2*SW^6 + 1024*cos^2*CW^2*MB^9*MC*MZ^2*s^2*SW^6 + 
    1536*CW^2*MB^8*MC^2*MZ^2*s^2*SW^6 + 1536*cos^2*CW^2*MB^8*MC^2*MZ^2*s^2*
     SW^6 - 3840*CW^2*MB^6*MC^4*MZ^2*s^2*SW^6 - 3840*cos^2*CW^2*MB^6*MC^4*
     MZ^2*s^2*SW^6 - 6144*CW^2*MB^5*MC^5*MZ^2*s^2*SW^6 - 
    6144*cos^2*CW^2*MB^5*MC^5*MZ^2*s^2*SW^6 - 3072*CW^2*MB^4*MC^6*MZ^2*s^2*
     SW^6 - 3072*cos^2*CW^2*MB^4*MC^6*MZ^2*s^2*SW^6 + 
    3072*CW^2*MB^3*MC^7*MZ^2*s^2*SW^6 + 3072*cos^2*CW^2*MB^3*MC^7*MZ^2*s^2*
     SW^6 + 6144*CW^2*MB^2*MC^8*MZ^2*s^2*SW^6 + 6144*cos^2*CW^2*MB^2*MC^8*
     MZ^2*s^2*SW^6 + 4096*CW^2*MB*MC^9*MZ^2*s^2*SW^6 + 
    4096*cos^2*CW^2*MB*MC^9*MZ^2*s^2*SW^6 + 1024*CW^2*MC^10*MZ^2*s^2*SW^6 + 
    1024*cos^2*CW^2*MC^10*MZ^2*s^2*SW^6 + 256*MB^10*s^3*SW^6 + 
    256*cos^2*MB^10*s^3*SW^6 - 256*CW^2*MB^10*s^3*SW^6 - 
    256*cos^2*CW^2*MB^10*s^3*SW^6 + 1024*MB^9*MC*s^3*SW^6 + 
    1024*cos^2*MB^9*MC*s^3*SW^6 - 1024*CW^2*MB^9*MC*s^3*SW^6 - 
    1024*cos^2*CW^2*MB^9*MC*s^3*SW^6 + 1536*MB^8*MC^2*s^3*SW^6 + 
    1536*cos^2*MB^8*MC^2*s^3*SW^6 - 1536*CW^2*MB^8*MC^2*s^3*SW^6 - 
    1536*cos^2*CW^2*MB^8*MC^2*s^3*SW^6 + 192*MB^7*MC^3*s^3*SW^6 + 
    192*cos^2*MB^7*MC^3*s^3*SW^6 - 3072*MB^6*MC^4*s^3*SW^6 - 
    3072*cos^2*MB^6*MC^4*s^3*SW^6 + 3840*CW^2*MB^6*MC^4*s^3*SW^6 + 
    3840*cos^2*CW^2*MB^6*MC^4*s^3*SW^6 - 4992*MB^5*MC^5*s^3*SW^6 - 
    4992*cos^2*MB^5*MC^5*s^3*SW^6 + 6144*CW^2*MB^5*MC^5*s^3*SW^6 + 
    6144*cos^2*CW^2*MB^5*MC^5*s^3*SW^6 - 2688*MB^4*MC^6*s^3*SW^6 - 
    2688*cos^2*MB^4*MC^6*s^3*SW^6 + 3072*CW^2*MB^4*MC^6*s^3*SW^6 + 
    3072*cos^2*CW^2*MB^4*MC^6*s^3*SW^6 + 1728*MB^3*MC^7*s^3*SW^6 + 
    1728*cos^2*MB^3*MC^7*s^3*SW^6 - 3072*CW^2*MB^3*MC^7*s^3*SW^6 - 
    3072*cos^2*CW^2*MB^3*MC^7*s^3*SW^6 + 3840*MB^2*MC^8*s^3*SW^6 + 
    3840*cos^2*MB^2*MC^8*s^3*SW^6 - 6144*CW^2*MB^2*MC^8*s^3*SW^6 - 
    6144*cos^2*CW^2*MB^2*MC^8*s^3*SW^6 + 2560*MB*MC^9*s^3*SW^6 + 
    2560*cos^2*MB*MC^9*s^3*SW^6 - 4096*CW^2*MB*MC^9*s^3*SW^6 - 
    4096*cos^2*CW^2*MB*MC^9*s^3*SW^6 + 640*MC^10*s^3*SW^6 + 
    640*cos^2*MC^10*s^3*SW^6 - 1024*CW^2*MC^10*s^3*SW^6 - 
    1024*cos^2*CW^2*MC^10*s^3*SW^6 + 512*MB^12*s^2*SW^8 + 
    512*cos^2*MB^12*s^2*SW^8 + 3072*MB^11*MC*s^2*SW^8 + 
    3072*cos^2*MB^11*MC*s^2*SW^8 + 7680*MB^10*MC^2*s^2*SW^8 + 
    7680*cos^2*MB^10*MC^2*s^2*SW^8 + 8192*MB^9*MC^3*s^2*SW^8 + 
    8192*cos^2*MB^9*MC^3*s^2*SW^8 - 4608*MB^8*MC^4*s^2*SW^8 - 
    4608*cos^2*MB^8*MC^4*s^2*SW^8 - 27648*MB^7*MC^5*s^2*SW^8 - 
    27648*cos^2*MB^7*MC^5*s^2*SW^8 - 38400*MB^6*MC^6*s^2*SW^8 - 
    38400*cos^2*MB^6*MC^6*s^2*SW^8 - 18432*MB^5*MC^7*s^2*SW^8 - 
    18432*cos^2*MB^5*MC^7*s^2*SW^8 + 18432*MB^4*MC^8*s^2*SW^8 + 
    18432*cos^2*MB^4*MC^8*s^2*SW^8 + 38912*MB^3*MC^9*s^2*SW^8 + 
    38912*cos^2*MB^3*MC^9*s^2*SW^8 + 30720*MB^2*MC^10*s^2*SW^8 + 
    30720*cos^2*MB^2*MC^10*s^2*SW^8 + 12288*MB*MC^11*s^2*SW^8 + 
    12288*cos^2*MB*MC^11*s^2*SW^8 + 2048*MC^12*s^2*SW^8 + 
    2048*cos^2*MC^12*s^2*SW^8 - 128*MB^10*s^3*SW^8 - 
    128*cos^2*MB^10*s^3*SW^8 - 512*MB^9*MC*s^3*SW^8 - 
    512*cos^2*MB^9*MC*s^3*SW^8 - 768*MB^8*MC^2*s^3*SW^8 - 
    768*cos^2*MB^8*MC^2*s^3*SW^8 + 1920*MB^6*MC^4*s^3*SW^8 + 
    1920*cos^2*MB^6*MC^4*s^3*SW^8 + 3072*MB^5*MC^5*s^3*SW^8 + 
    3072*cos^2*MB^5*MC^5*s^3*SW^8 + 1536*MB^4*MC^6*s^3*SW^8 + 
    1536*cos^2*MB^4*MC^6*s^3*SW^8 - 1536*MB^3*MC^7*s^3*SW^8 - 
    1536*cos^2*MB^3*MC^7*s^3*SW^8 - 3072*MB^2*MC^8*s^3*SW^8 - 
    3072*cos^2*MB^2*MC^8*s^3*SW^8 - 2048*MB*MC^9*s^3*SW^8 - 
    2048*cos^2*MB*MC^9*s^3*SW^8 - 512*MC^10*s^3*SW^8 - 
    512*cos^2*MC^10*s^3*SW^8))/(93312*CW^4*MB^6*MC^6*s^(11/2)*
  ((-I)*GammaZ*MZ - MZ^2 + s)*(I*GammaZ*MZ - MZ^2 + s)*SW^4)
