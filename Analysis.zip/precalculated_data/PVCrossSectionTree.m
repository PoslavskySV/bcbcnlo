(* Created with the Wolfram Language : www.wolfram.com *)
(-8*alphaS^2*e^4*fBc^4*(MB + MC)^8*(MB^3 - 2*MC^3)^2*Pi*
  (2*MB + 2*MC - Sqrt[s])*(2*MB + 2*MC + Sqrt[s])*
  Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s])/(2187*MB^6*MC^6*s^(11/2))
