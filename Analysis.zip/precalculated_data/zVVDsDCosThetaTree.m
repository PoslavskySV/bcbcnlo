(* Created with the Wolfram Language : www.wolfram.com *)
(alphaS^2*e^4*fBc^4*(MB + MC)^4*Pi*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
  (-144*MB^14*s^2 + 720*cos^2*MB^14*s^2 - 864*MB^13*MC*s^2 + 
   4320*cos^2*MB^13*MC*s^2 - 2160*MB^12*MC^2*s^2 + 
   10800*cos^2*MB^12*MC^2*s^2 - 2880*MB^11*MC^3*s^2 + 
   14400*cos^2*MB^11*MC^3*s^2 - 3600*MB^10*MC^4*s^2 + 
   11088*cos^2*MB^10*MC^4*s^2 - 9504*MB^9*MC^5*s^2 + 
   6048*cos^2*MB^9*MC^5*s^2 - 21744*MB^8*MC^6*s^2 + 
   5040*cos^2*MB^8*MC^6*s^2 - 28800*MB^7*MC^7*s^2 + 
   5760*cos^2*MB^7*MC^7*s^2 - 21744*MB^6*MC^8*s^2 + 
   5040*cos^2*MB^6*MC^8*s^2 - 9504*MB^5*MC^9*s^2 + 6048*cos^2*MB^5*MC^9*s^2 - 
   3600*MB^4*MC^10*s^2 + 11088*cos^2*MB^4*MC^10*s^2 - 2880*MB^3*MC^11*s^2 + 
   14400*cos^2*MB^3*MC^11*s^2 - 2160*MB^2*MC^12*s^2 + 
   10800*cos^2*MB^2*MC^12*s^2 - 864*MB*MC^13*s^2 + 4320*cos^2*MB*MC^13*s^2 - 
   144*MC^14*s^2 + 720*cos^2*MC^14*s^2 - 108*MB^12*s^3 - 
   324*cos^2*MB^12*s^3 - 720*MB^11*MC*s^3 - 1296*cos^2*MB^11*MC*s^3 - 
   1872*MB^10*MC^2*s^3 - 2016*cos^2*MB^10*MC^2*s^3 - 2736*MB^9*MC^3*s^3 - 
   1584*cos^2*MB^9*MC^3*s^3 - 2628*MB^8*MC^4*s^3 - 972*cos^2*MB^8*MC^4*s^3 - 
   1728*MB^7*MC^5*s^3 - 1152*cos^2*MB^7*MC^5*s^3 - 1152*MB^6*MC^6*s^3 - 
   1440*cos^2*MB^6*MC^6*s^3 - 1728*MB^5*MC^7*s^3 - 1152*cos^2*MB^5*MC^7*s^3 - 
   2628*MB^4*MC^8*s^3 - 972*cos^2*MB^4*MC^8*s^3 - 2736*MB^3*MC^9*s^3 - 
   1584*cos^2*MB^3*MC^9*s^3 - 1872*MB^2*MC^10*s^3 - 
   2016*cos^2*MB^2*MC^10*s^3 - 720*MB*MC^11*s^3 - 1296*cos^2*MB*MC^11*s^3 - 
   108*MC^12*s^3 - 324*cos^2*MC^12*s^3 + 36*MB^10*s^4 + 36*cos^2*MB^10*s^4 + 
   144*MB^9*MC*s^4 + 72*cos^2*MB^9*MC*s^4 + 162*MB^8*MC^2*s^4 + 
   90*cos^2*MB^8*MC^2*s^4 + 108*MB^7*MC^3*s^4 + 108*cos^2*MB^7*MC^3*s^4 + 
   90*MB^6*MC^4*s^4 + 162*cos^2*MB^6*MC^4*s^4 + 72*MB^5*MC^5*s^4 + 
   216*cos^2*MB^5*MC^5*s^4 + 90*MB^4*MC^6*s^4 + 162*cos^2*MB^4*MC^6*s^4 + 
   108*MB^3*MC^7*s^4 + 108*cos^2*MB^3*MC^7*s^4 + 162*MB^2*MC^8*s^4 + 
   90*cos^2*MB^2*MC^8*s^4 + 144*MB*MC^9*s^4 + 72*cos^2*MB*MC^9*s^4 + 
   36*MC^10*s^4 + 36*cos^2*MC^10*s^4 + 9*MB^6*MC^2*s^5 - 
   9*cos^2*MB^6*MC^2*s^5 + 18*MB^4*MC^4*s^5 - 18*cos^2*MB^4*MC^4*s^5 + 
   9*MB^2*MC^6*s^5 - 9*cos^2*MB^2*MC^6*s^5 + 288*cos*MB^12*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 1440*cos*MB^11*MC*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 2880*cos*MB^10*MC^2*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 3168*cos*MB^9*MC^3*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 2592*cos*MB^8*MC^4*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 1728*cos*MB^7*MC^5*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] - 1728*cos*MB^5*MC^7*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] - 2592*cos*MB^4*MC^8*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] - 3168*cos*MB^3*MC^9*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] - 2880*cos*MB^2*MC^10*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] - 1440*cos*MB*MC^11*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] - 288*cos*MC^12*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] - 72*cos*MB^10*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] - 216*cos*MB^9*MC*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] - 216*cos*MB^8*MC^2*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] - 144*cos*MB^7*MC^3*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] - 144*cos*MB^6*MC^4*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 144*cos*MB^4*MC^6*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 144*cos*MB^3*MC^7*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 216*cos*MB^2*MC^8*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 216*cos*MB*MC^9*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 72*cos*MC^10*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s] + 2304*CW^2*MB^14*MZ^2*s*SW^2 - 
   2304*cos^2*CW^2*MB^14*MZ^2*s*SW^2 + 13824*CW^2*MB^13*MC*MZ^2*s*SW^2 - 
   13824*cos^2*CW^2*MB^13*MC*MZ^2*s*SW^2 + 34560*CW^2*MB^12*MC^2*MZ^2*s*
    SW^2 - 34560*cos^2*CW^2*MB^12*MC^2*MZ^2*s*SW^2 + 
   46080*CW^2*MB^11*MC^3*MZ^2*s*SW^2 - 46080*cos^2*CW^2*MB^11*MC^3*MZ^2*s*
    SW^2 + 41472*CW^2*MB^10*MC^4*MZ^2*s*SW^2 - 41472*cos^2*CW^2*MB^10*MC^4*
    MZ^2*s*SW^2 + 55296*CW^2*MB^9*MC^5*MZ^2*s*SW^2 - 
   55296*cos^2*CW^2*MB^9*MC^5*MZ^2*s*SW^2 + 105984*CW^2*MB^8*MC^6*MZ^2*s*
    SW^2 - 105984*cos^2*CW^2*MB^8*MC^6*MZ^2*s*SW^2 + 
   138240*CW^2*MB^7*MC^7*MZ^2*s*SW^2 - 138240*cos^2*CW^2*MB^7*MC^7*MZ^2*s*
    SW^2 + 108288*CW^2*MB^6*MC^8*MZ^2*s*SW^2 - 108288*cos^2*CW^2*MB^6*MC^8*
    MZ^2*s*SW^2 + 69120*CW^2*MB^5*MC^9*MZ^2*s*SW^2 - 
   69120*cos^2*CW^2*MB^5*MC^9*MZ^2*s*SW^2 + 76032*CW^2*MB^4*MC^10*MZ^2*s*
    SW^2 - 76032*cos^2*CW^2*MB^4*MC^10*MZ^2*s*SW^2 + 
   92160*CW^2*MB^3*MC^11*MZ^2*s*SW^2 - 92160*cos^2*CW^2*MB^3*MC^11*MZ^2*s*
    SW^2 + 69120*CW^2*MB^2*MC^12*MZ^2*s*SW^2 - 69120*cos^2*CW^2*MB^2*MC^12*
    MZ^2*s*SW^2 + 27648*CW^2*MB*MC^13*MZ^2*s*SW^2 - 
   27648*cos^2*CW^2*MB*MC^13*MZ^2*s*SW^2 + 4608*CW^2*MC^14*MZ^2*s*SW^2 - 
   4608*cos^2*CW^2*MC^14*MZ^2*s*SW^2 + 1728*MB^14*s^2*SW^2 - 
   4032*cos^2*MB^14*s^2*SW^2 - 2304*CW^2*MB^14*s^2*SW^2 + 
   2304*cos^2*CW^2*MB^14*s^2*SW^2 + 10368*MB^13*MC*s^2*SW^2 - 
   24192*cos^2*MB^13*MC*s^2*SW^2 - 13824*CW^2*MB^13*MC*s^2*SW^2 + 
   13824*cos^2*CW^2*MB^13*MC*s^2*SW^2 + 25920*MB^12*MC^2*s^2*SW^2 - 
   60480*cos^2*MB^12*MC^2*s^2*SW^2 - 34560*CW^2*MB^12*MC^2*s^2*SW^2 + 
   34560*cos^2*CW^2*MB^12*MC^2*s^2*SW^2 + 34560*MB^11*MC^3*s^2*SW^2 - 
   80640*cos^2*MB^11*MC^3*s^2*SW^2 - 46080*CW^2*MB^11*MC^3*s^2*SW^2 + 
   46080*cos^2*CW^2*MB^11*MC^3*s^2*SW^2 + 35136*MB^10*MC^4*s^2*SW^2 - 
   65088*cos^2*MB^10*MC^4*s^2*SW^2 - 41472*CW^2*MB^10*MC^4*s^2*SW^2 + 
   41472*cos^2*CW^2*MB^10*MC^4*s^2*SW^2 + 65664*MB^9*MC^5*s^2*SW^2 - 
   51840*cos^2*MB^9*MC^5*s^2*SW^2 - 55296*CW^2*MB^9*MC^5*s^2*SW^2 + 
   55296*cos^2*CW^2*MB^9*MC^5*s^2*SW^2 + 139968*MB^8*MC^6*s^2*SW^2 - 
   73152*cos^2*MB^8*MC^6*s^2*SW^2 - 105984*CW^2*MB^8*MC^6*s^2*SW^2 + 
   105984*cos^2*CW^2*MB^8*MC^6*s^2*SW^2 + 184320*MB^7*MC^7*s^2*SW^2 - 
   92160*cos^2*MB^7*MC^7*s^2*SW^2 - 138240*CW^2*MB^7*MC^7*s^2*SW^2 + 
   138240*cos^2*CW^2*MB^7*MC^7*s^2*SW^2 + 141120*MB^6*MC^8*s^2*SW^2 - 
   74304*cos^2*MB^6*MC^8*s^2*SW^2 - 108288*CW^2*MB^6*MC^8*s^2*SW^2 + 
   108288*cos^2*CW^2*MB^6*MC^8*s^2*SW^2 + 72576*MB^5*MC^9*s^2*SW^2 - 
   58752*cos^2*MB^5*MC^9*s^2*SW^2 - 69120*CW^2*MB^5*MC^9*s^2*SW^2 + 
   69120*cos^2*CW^2*MB^5*MC^9*s^2*SW^2 + 52416*MB^4*MC^10*s^2*SW^2 - 
   82368*cos^2*MB^4*MC^10*s^2*SW^2 - 76032*CW^2*MB^4*MC^10*s^2*SW^2 + 
   76032*cos^2*CW^2*MB^4*MC^10*s^2*SW^2 + 57600*MB^3*MC^11*s^2*SW^2 - 
   103680*cos^2*MB^3*MC^11*s^2*SW^2 - 92160*CW^2*MB^3*MC^11*s^2*SW^2 + 
   92160*cos^2*CW^2*MB^3*MC^11*s^2*SW^2 + 43200*MB^2*MC^12*s^2*SW^2 - 
   77760*cos^2*MB^2*MC^12*s^2*SW^2 - 69120*CW^2*MB^2*MC^12*s^2*SW^2 + 
   69120*cos^2*CW^2*MB^2*MC^12*s^2*SW^2 + 17280*MB*MC^13*s^2*SW^2 - 
   31104*cos^2*MB*MC^13*s^2*SW^2 - 27648*CW^2*MB*MC^13*s^2*SW^2 + 
   27648*cos^2*CW^2*MB*MC^13*s^2*SW^2 + 2880*MC^14*s^2*SW^2 - 
   5184*cos^2*MC^14*s^2*SW^2 - 4608*CW^2*MC^14*s^2*SW^2 + 
   4608*cos^2*CW^2*MC^14*s^2*SW^2 - 192*CW^2*MB^12*MZ^2*s^2*SW^2 + 
   960*cos^2*CW^2*MB^12*MZ^2*s^2*SW^2 + 768*CW^2*MB^11*MC*MZ^2*s^2*SW^2 + 
   3840*cos^2*CW^2*MB^11*MC*MZ^2*s^2*SW^2 + 5376*CW^2*MB^10*MC^2*MZ^2*s^2*
    SW^2 + 6144*cos^2*CW^2*MB^10*MC^2*MZ^2*s^2*SW^2 + 
   12288*CW^2*MB^9*MC^3*MZ^2*s^2*SW^2 + 5376*cos^2*CW^2*MB^9*MC^3*MZ^2*s^2*
    SW^2 + 18048*CW^2*MB^8*MC^4*MZ^2*s^2*SW^2 + 7296*cos^2*CW^2*MB^8*MC^4*
    MZ^2*s^2*SW^2 + 21504*CW^2*MB^7*MC^5*MZ^2*s^2*SW^2 + 
   17664*cos^2*CW^2*MB^7*MC^5*MZ^2*s^2*SW^2 + 23040*CW^2*MB^6*MC^6*MZ^2*s^2*
    SW^2 + 25344*cos^2*CW^2*MB^6*MC^6*MZ^2*s^2*SW^2 + 
   24576*CW^2*MB^5*MC^7*MZ^2*s^2*SW^2 + 19200*cos^2*CW^2*MB^5*MC^7*MZ^2*s^2*
    SW^2 + 26304*CW^2*MB^4*MC^8*MZ^2*s^2*SW^2 + 10560*cos^2*CW^2*MB^4*MC^8*
    MZ^2*s^2*SW^2 + 22272*CW^2*MB^3*MC^9*MZ^2*s^2*SW^2 + 
   10752*cos^2*CW^2*MB^3*MC^9*MZ^2*s^2*SW^2 + 10752*CW^2*MB^2*MC^10*MZ^2*s^2*
    SW^2 + 12288*cos^2*CW^2*MB^2*MC^10*MZ^2*s^2*SW^2 + 
   1536*CW^2*MB*MC^11*MZ^2*s^2*SW^2 + 7680*cos^2*CW^2*MB*MC^11*MZ^2*s^2*
    SW^2 - 384*CW^2*MC^12*MZ^2*s^2*SW^2 + 1920*cos^2*CW^2*MC^12*MZ^2*s^2*
    SW^2 + 336*MB^12*s^3*SW^2 + 1776*cos^2*MB^12*s^3*SW^2 + 
   192*CW^2*MB^12*s^3*SW^2 - 960*cos^2*CW^2*MB^12*s^3*SW^2 + 
   3264*MB^11*MC*s^3*SW^2 + 7104*cos^2*MB^11*MC*s^3*SW^2 - 
   768*CW^2*MB^11*MC*s^3*SW^2 - 3840*cos^2*CW^2*MB^11*MC*s^3*SW^2 + 
   10176*MB^10*MC^2*s^3*SW^2 + 11136*cos^2*MB^10*MC^2*s^3*SW^2 - 
   5376*CW^2*MB^10*MC^2*s^3*SW^2 - 6144*cos^2*CW^2*MB^10*MC^2*s^3*SW^2 + 
   17088*MB^9*MC^3*s^3*SW^2 + 9024*cos^2*MB^9*MC^3*s^3*SW^2 - 
   12288*CW^2*MB^9*MC^3*s^3*SW^2 - 5376*cos^2*CW^2*MB^9*MC^3*s^3*SW^2 + 
   19536*MB^8*MC^4*s^3*SW^2 + 7536*cos^2*MB^8*MC^4*s^3*SW^2 - 
   18048*CW^2*MB^8*MC^4*s^3*SW^2 - 7296*cos^2*CW^2*MB^8*MC^4*s^3*SW^2 + 
   17664*MB^7*MC^5*s^3*SW^2 + 13440*cos^2*MB^7*MC^5*s^3*SW^2 - 
   21504*CW^2*MB^7*MC^5*s^3*SW^2 - 17664*cos^2*CW^2*MB^7*MC^5*s^3*SW^2 + 
   16128*MB^6*MC^6*s^3*SW^2 + 18432*cos^2*MB^6*MC^6*s^3*SW^2 - 
   23040*CW^2*MB^6*MC^6*s^3*SW^2 - 25344*cos^2*CW^2*MB^6*MC^6*s^3*SW^2 + 
   19200*MB^5*MC^7*s^3*SW^2 + 14208*cos^2*MB^5*MC^7*s^3*SW^2 - 
   24576*CW^2*MB^5*MC^7*s^3*SW^2 - 19200*cos^2*CW^2*MB^5*MC^7*s^3*SW^2 + 
   23664*MB^4*MC^8*s^3*SW^2 + 9168*cos^2*MB^4*MC^8*s^3*SW^2 - 
   26304*CW^2*MB^4*MC^8*s^3*SW^2 - 10560*cos^2*CW^2*MB^4*MC^8*s^3*SW^2 + 
   22080*MB^3*MC^9*s^3*SW^2 + 11712*cos^2*MB^3*MC^9*s^3*SW^2 - 
   22272*CW^2*MB^3*MC^9*s^3*SW^2 - 10752*cos^2*CW^2*MB^3*MC^9*s^3*SW^2 + 
   12864*MB^2*MC^10*s^3*SW^2 + 14208*cos^2*MB^2*MC^10*s^3*SW^2 - 
   10752*CW^2*MB^2*MC^10*s^3*SW^2 - 12288*cos^2*CW^2*MB^2*MC^10*s^3*SW^2 + 
   3648*MB*MC^11*s^3*SW^2 + 9024*cos^2*MB*MC^11*s^3*SW^2 - 
   1536*CW^2*MB*MC^11*s^3*SW^2 - 7680*cos^2*CW^2*MB*MC^11*s^3*SW^2 + 
   240*MC^12*s^3*SW^2 + 2256*cos^2*MC^12*s^3*SW^2 + 384*CW^2*MC^12*s^3*SW^2 - 
   1920*cos^2*CW^2*MC^12*s^3*SW^2 - 96*CW^2*MB^10*MZ^2*s^3*SW^2 - 
   96*cos^2*CW^2*MB^10*MZ^2*s^3*SW^2 - 576*CW^2*MB^9*MC*MZ^2*s^3*SW^2 - 
   192*cos^2*CW^2*MB^9*MC*MZ^2*s^3*SW^2 - 768*CW^2*MB^8*MC^2*MZ^2*s^3*SW^2 - 
   384*cos^2*CW^2*MB^8*MC^2*MZ^2*s^3*SW^2 - 768*CW^2*MB^7*MC^3*MZ^2*s^3*
    SW^2 - 576*cos^2*CW^2*MB^7*MC^3*MZ^2*s^3*SW^2 - 
   1056*CW^2*MB^6*MC^4*MZ^2*s^3*SW^2 - 1440*cos^2*CW^2*MB^6*MC^4*MZ^2*s^3*
    SW^2 - 1152*CW^2*MB^5*MC^5*MZ^2*s^3*SW^2 - 2304*cos^2*CW^2*MB^5*MC^5*MZ^2*
    s^3*SW^2 - 960*CW^2*MB^4*MC^6*MZ^2*s^3*SW^2 - 
   1728*cos^2*CW^2*MB^4*MC^6*MZ^2*s^3*SW^2 - 960*CW^2*MB^3*MC^7*MZ^2*s^3*
    SW^2 - 1152*cos^2*CW^2*MB^3*MC^7*MZ^2*s^3*SW^2 - 
   1536*CW^2*MB^2*MC^8*MZ^2*s^3*SW^2 - 768*cos^2*CW^2*MB^2*MC^8*MZ^2*s^3*
    SW^2 - 1152*CW^2*MB*MC^9*MZ^2*s^3*SW^2 - 384*cos^2*CW^2*MB*MC^9*MZ^2*s^3*
    SW^2 - 192*CW^2*MC^10*MZ^2*s^3*SW^2 - 192*cos^2*CW^2*MC^10*MZ^2*s^3*
    SW^2 - 192*MB^10*s^4*SW^2 - 192*cos^2*MB^10*s^4*SW^2 + 
   96*CW^2*MB^10*s^4*SW^2 + 96*cos^2*CW^2*MB^10*s^4*SW^2 - 
   864*MB^9*MC*s^4*SW^2 - 384*cos^2*MB^9*MC*s^4*SW^2 + 
   576*CW^2*MB^9*MC*s^4*SW^2 + 192*cos^2*CW^2*MB^9*MC*s^4*SW^2 - 
   1032*MB^8*MC^2*s^4*SW^2 - 552*cos^2*MB^8*MC^2*s^4*SW^2 + 
   768*CW^2*MB^8*MC^2*s^4*SW^2 + 384*cos^2*CW^2*MB^8*MC^2*s^4*SW^2 - 
   816*MB^7*MC^3*s^4*SW^2 - 720*cos^2*MB^7*MC^3*s^4*SW^2 + 
   768*CW^2*MB^7*MC^3*s^4*SW^2 + 576*cos^2*CW^2*MB^7*MC^3*s^4*SW^2 - 
   888*MB^6*MC^4*s^4*SW^2 - 1368*cos^2*MB^6*MC^4*s^4*SW^2 + 
   1056*CW^2*MB^6*MC^4*s^4*SW^2 + 1440*cos^2*CW^2*MB^6*MC^4*s^4*SW^2 - 
   864*MB^5*MC^5*s^4*SW^2 - 2016*cos^2*MB^5*MC^5*s^4*SW^2 + 
   1152*CW^2*MB^5*MC^5*s^4*SW^2 + 2304*cos^2*CW^2*MB^5*MC^5*s^4*SW^2 - 
   840*MB^4*MC^6*s^4*SW^2 - 1512*cos^2*MB^4*MC^6*s^4*SW^2 + 
   960*CW^2*MB^4*MC^6*s^4*SW^2 + 1728*cos^2*CW^2*MB^4*MC^6*s^4*SW^2 - 
   912*MB^3*MC^7*s^4*SW^2 - 1008*cos^2*MB^3*MC^7*s^4*SW^2 + 
   960*CW^2*MB^3*MC^7*s^4*SW^2 + 1152*cos^2*CW^2*MB^3*MC^7*s^4*SW^2 - 
   1416*MB^2*MC^8*s^4*SW^2 - 744*cos^2*MB^2*MC^8*s^4*SW^2 + 
   1536*CW^2*MB^2*MC^8*s^4*SW^2 + 768*cos^2*CW^2*MB^2*MC^8*s^4*SW^2 - 
   1152*MB*MC^9*s^4*SW^2 - 480*cos^2*MB*MC^9*s^4*SW^2 + 
   1152*CW^2*MB*MC^9*s^4*SW^2 + 384*cos^2*CW^2*MB*MC^9*s^4*SW^2 - 
   240*MC^10*s^4*SW^2 - 240*cos^2*MC^10*s^4*SW^2 + 192*CW^2*MC^10*s^4*SW^2 + 
   192*cos^2*CW^2*MC^10*s^4*SW^2 - 48*CW^2*MB^6*MC^2*MZ^2*s^4*SW^2 + 
   48*cos^2*CW^2*MB^6*MC^2*MZ^2*s^4*SW^2 - 144*CW^2*MB^4*MC^4*MZ^2*s^4*SW^2 + 
   144*cos^2*CW^2*MB^4*MC^4*MZ^2*s^4*SW^2 - 96*CW^2*MB^2*MC^6*MZ^2*s^4*SW^2 + 
   96*cos^2*CW^2*MB^2*MC^6*MZ^2*s^4*SW^2 - 60*MB^6*MC^2*s^5*SW^2 + 
   60*cos^2*MB^6*MC^2*s^5*SW^2 + 48*CW^2*MB^6*MC^2*s^5*SW^2 - 
   48*cos^2*CW^2*MB^6*MC^2*s^5*SW^2 - 144*MB^4*MC^4*s^5*SW^2 + 
   144*cos^2*MB^4*MC^4*s^5*SW^2 + 144*CW^2*MB^4*MC^4*s^5*SW^2 - 
   144*cos^2*CW^2*MB^4*MC^4*s^5*SW^2 - 84*MB^2*MC^6*s^5*SW^2 + 
   84*cos^2*MB^2*MC^6*s^5*SW^2 + 96*CW^2*MB^2*MC^6*s^5*SW^2 - 
   96*cos^2*CW^2*MB^2*MC^6*s^5*SW^2 - 768*cos*CW^2*MB^12*MZ^2*s^(3/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 3840*cos*CW^2*MB^11*MC*MZ^2*
    s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
   7680*cos*CW^2*MB^10*MC^2*MZ^2*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
    SW^2 - 9216*cos*CW^2*MB^9*MC^3*MZ^2*s^(3/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 10752*cos*CW^2*MB^8*MC^4*MZ^2*
    s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
   12288*cos*CW^2*MB^7*MC^5*MZ^2*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
    SW^2 - 7680*cos*CW^2*MB^6*MC^6*MZ^2*s^(3/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 1536*cos*CW^2*MB^5*MC^7*MZ^2*
    s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
   9984*cos*CW^2*MB^4*MC^8*MZ^2*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
    SW^2 + 16128*cos*CW^2*MB^3*MC^9*MZ^2*s^(3/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 15360*cos*CW^2*MB^2*MC^10*
    MZ^2*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
   7680*cos*CW^2*MB*MC^11*MZ^2*s^(3/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
    SW^2 + 1536*cos*CW^2*MC^12*MZ^2*s^(3/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 1536*cos*MB^12*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 768*cos*CW^2*MB^12*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 7680*cos*MB^11*MC*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 3840*cos*CW^2*MB^11*MC*
    s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
   15360*cos*MB^10*MC^2*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
   7680*cos*CW^2*MB^10*MC^2*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
    SW^2 - 17280*cos*MB^9*MC^3*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
    SW^2 + 9216*cos*CW^2*MB^9*MC^3*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 15744*cos*MB^8*MC^4*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 10752*cos*CW^2*MB^8*MC^4*
    s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
   13056*cos*MB^7*MC^5*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
   12288*cos*CW^2*MB^7*MC^5*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
    SW^2 - 3840*cos*MB^6*MC^6*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
    SW^2 + 7680*cos*CW^2*MB^6*MC^6*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 7680*cos*MB^5*MC^7*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 1536*cos*CW^2*MB^5*MC^7*
    s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
   15360*cos*MB^4*MC^8*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
   9984*cos*CW^2*MB^4*MC^8*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
    SW^2 + 20736*cos*MB^3*MC^9*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
    SW^2 - 16128*cos*CW^2*MB^3*MC^9*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 19200*cos*MB^2*MC^10*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 15360*cos*CW^2*MB^2*MC^10*
    s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
   9600*cos*MB*MC^11*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
   7680*cos*CW^2*MB*MC^11*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
   1920*cos*MC^12*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
   1536*cos*CW^2*MC^12*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
   192*cos*CW^2*MB^10*MZ^2*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
    SW^2 + 576*cos*CW^2*MB^9*MC*MZ^2*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 576*cos*CW^2*MB^8*MC^2*MZ^2*
    s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
   576*cos*CW^2*MB^7*MC^3*MZ^2*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
    SW^2 + 960*cos*CW^2*MB^6*MC^4*MZ^2*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 576*cos*CW^2*MB^5*MC^5*MZ^2*
    s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
   192*cos*CW^2*MB^4*MC^6*MZ^2*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
    SW^2 - 576*cos*CW^2*MB^3*MC^7*MZ^2*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 1152*cos*CW^2*MB^2*MC^8*MZ^2*
    s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
   1152*cos*CW^2*MB*MC^9*MZ^2*s^(5/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
    SW^2 - 384*cos*CW^2*MC^10*MZ^2*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 384*cos*MB^10*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 192*cos*CW^2*MB^10*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 1152*cos*MB^9*MC*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 576*cos*CW^2*MB^9*MC*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 1152*cos*MB^8*MC^2*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 576*cos*CW^2*MB^8*MC^2*
    s^(7/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
   864*cos*MB^7*MC^3*s^(7/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
   576*cos*CW^2*MB^7*MC^3*s^(7/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
   1056*cos*MB^6*MC^4*s^(7/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
   960*cos*CW^2*MB^6*MC^4*s^(7/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
   288*cos*MB^5*MC^5*s^(7/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
   576*cos*CW^2*MB^5*MC^5*s^(7/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
   672*cos*MB^4*MC^6*s^(7/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
   192*cos*CW^2*MB^4*MC^6*s^(7/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
   864*cos*MB^3*MC^7*s^(7/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
   576*cos*CW^2*MB^3*MC^7*s^(7/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
   1440*cos*MB^2*MC^8*s^(7/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
   1152*cos*CW^2*MB^2*MC^8*s^(7/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
    SW^2 - 1440*cos*MB*MC^9*s^(7/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
    SW^2 + 1152*cos*CW^2*MB*MC^9*s^(7/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*
    SW^2 - 480*cos*MC^10*s^(7/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 + 
   384*cos*CW^2*MC^10*s^(7/2)*Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^2 - 
   6144*CW^4*GammaZ^2*MB^14*MZ^2*SW^4 + 6144*cos^2*CW^4*GammaZ^2*MB^14*MZ^2*
    SW^4 - 36864*CW^4*GammaZ^2*MB^13*MC*MZ^2*SW^4 + 
   36864*cos^2*CW^4*GammaZ^2*MB^13*MC*MZ^2*SW^4 - 
   92160*CW^4*GammaZ^2*MB^12*MC^2*MZ^2*SW^4 + 92160*cos^2*CW^4*GammaZ^2*MB^12*
    MC^2*MZ^2*SW^4 - 122880*CW^4*GammaZ^2*MB^11*MC^3*MZ^2*SW^4 + 
   122880*cos^2*CW^4*GammaZ^2*MB^11*MC^3*MZ^2*SW^4 - 
   116736*CW^4*GammaZ^2*MB^10*MC^4*MZ^2*SW^4 + 116736*cos^2*CW^4*GammaZ^2*
    MB^10*MC^4*MZ^2*SW^4 - 184320*CW^4*GammaZ^2*MB^9*MC^5*MZ^2*SW^4 + 
   184320*cos^2*CW^4*GammaZ^2*MB^9*MC^5*MZ^2*SW^4 - 
   374784*CW^4*GammaZ^2*MB^8*MC^6*MZ^2*SW^4 + 374784*cos^2*CW^4*GammaZ^2*MB^8*
    MC^6*MZ^2*SW^4 - 491520*CW^4*GammaZ^2*MB^7*MC^7*MZ^2*SW^4 + 
   491520*cos^2*CW^4*GammaZ^2*MB^7*MC^7*MZ^2*SW^4 - 
   393216*CW^4*GammaZ^2*MB^6*MC^8*MZ^2*SW^4 + 393216*cos^2*CW^4*GammaZ^2*MB^6*
    MC^8*MZ^2*SW^4 - 294912*CW^4*GammaZ^2*MB^5*MC^9*MZ^2*SW^4 + 
   294912*cos^2*CW^4*GammaZ^2*MB^5*MC^9*MZ^2*SW^4 - 
   393216*CW^4*GammaZ^2*MB^4*MC^10*MZ^2*SW^4 + 393216*cos^2*CW^4*GammaZ^2*
    MB^4*MC^10*MZ^2*SW^4 - 491520*CW^4*GammaZ^2*MB^3*MC^11*MZ^2*SW^4 + 
   491520*cos^2*CW^4*GammaZ^2*MB^3*MC^11*MZ^2*SW^4 - 
   368640*CW^4*GammaZ^2*MB^2*MC^12*MZ^2*SW^4 + 368640*cos^2*CW^4*GammaZ^2*
    MB^2*MC^12*MZ^2*SW^4 - 147456*CW^4*GammaZ^2*MB*MC^13*MZ^2*SW^4 + 
   147456*cos^2*CW^4*GammaZ^2*MB*MC^13*MZ^2*SW^4 - 
   24576*CW^4*GammaZ^2*MC^14*MZ^2*SW^4 + 24576*cos^2*CW^4*GammaZ^2*MC^14*MZ^2*
    SW^4 - 6144*CW^4*MB^14*MZ^4*SW^4 + 6144*cos^2*CW^4*MB^14*MZ^4*SW^4 - 
   36864*CW^4*MB^13*MC*MZ^4*SW^4 + 36864*cos^2*CW^4*MB^13*MC*MZ^4*SW^4 - 
   92160*CW^4*MB^12*MC^2*MZ^4*SW^4 + 92160*cos^2*CW^4*MB^12*MC^2*MZ^4*SW^4 - 
   122880*CW^4*MB^11*MC^3*MZ^4*SW^4 + 122880*cos^2*CW^4*MB^11*MC^3*MZ^4*
    SW^4 - 116736*CW^4*MB^10*MC^4*MZ^4*SW^4 + 116736*cos^2*CW^4*MB^10*MC^4*
    MZ^4*SW^4 - 184320*CW^4*MB^9*MC^5*MZ^4*SW^4 + 
   184320*cos^2*CW^4*MB^9*MC^5*MZ^4*SW^4 - 374784*CW^4*MB^8*MC^6*MZ^4*SW^4 + 
   374784*cos^2*CW^4*MB^8*MC^6*MZ^4*SW^4 - 491520*CW^4*MB^7*MC^7*MZ^4*SW^4 + 
   491520*cos^2*CW^4*MB^7*MC^7*MZ^4*SW^4 - 393216*CW^4*MB^6*MC^8*MZ^4*SW^4 + 
   393216*cos^2*CW^4*MB^6*MC^8*MZ^4*SW^4 - 294912*CW^4*MB^5*MC^9*MZ^4*SW^4 + 
   294912*cos^2*CW^4*MB^5*MC^9*MZ^4*SW^4 - 393216*CW^4*MB^4*MC^10*MZ^4*SW^4 + 
   393216*cos^2*CW^4*MB^4*MC^10*MZ^4*SW^4 - 491520*CW^4*MB^3*MC^11*MZ^4*
    SW^4 + 491520*cos^2*CW^4*MB^3*MC^11*MZ^4*SW^4 - 
   368640*CW^4*MB^2*MC^12*MZ^4*SW^4 + 368640*cos^2*CW^4*MB^2*MC^12*MZ^4*
    SW^4 - 147456*CW^4*MB*MC^13*MZ^4*SW^4 + 147456*cos^2*CW^4*MB*MC^13*MZ^4*
    SW^4 - 24576*CW^4*MC^14*MZ^4*SW^4 + 24576*cos^2*CW^4*MC^14*MZ^4*SW^4 + 
   512*CW^4*GammaZ^2*MB^12*MZ^2*s*SW^4 - 2560*cos^2*CW^4*GammaZ^2*MB^12*MZ^2*
    s*SW^4 - 12288*CW^2*MB^14*MZ^2*s*SW^4 + 12288*cos^2*CW^2*MB^14*MZ^2*s*
    SW^4 + 12288*CW^4*MB^14*MZ^2*s*SW^4 - 12288*cos^2*CW^4*MB^14*MZ^2*s*
    SW^4 - 2048*CW^4*GammaZ^2*MB^11*MC*MZ^2*s*SW^4 - 
   10240*cos^2*CW^4*GammaZ^2*MB^11*MC*MZ^2*s*SW^4 - 
   73728*CW^2*MB^13*MC*MZ^2*s*SW^4 + 73728*cos^2*CW^2*MB^13*MC*MZ^2*s*SW^4 + 
   73728*CW^4*MB^13*MC*MZ^2*s*SW^4 - 73728*cos^2*CW^4*MB^13*MC*MZ^2*s*SW^4 - 
   14336*CW^4*GammaZ^2*MB^10*MC^2*MZ^2*s*SW^4 - 16384*cos^2*CW^4*GammaZ^2*
    MB^10*MC^2*MZ^2*s*SW^4 - 184320*CW^2*MB^12*MC^2*MZ^2*s*SW^4 + 
   184320*cos^2*CW^2*MB^12*MC^2*MZ^2*s*SW^4 + 184320*CW^4*MB^12*MC^2*MZ^2*s*
    SW^4 - 184320*cos^2*CW^4*MB^12*MC^2*MZ^2*s*SW^4 - 
   34816*CW^4*GammaZ^2*MB^9*MC^3*MZ^2*s*SW^4 - 14336*cos^2*CW^4*GammaZ^2*MB^9*
    MC^3*MZ^2*s*SW^4 - 245760*CW^2*MB^11*MC^3*MZ^2*s*SW^4 + 
   245760*cos^2*CW^2*MB^11*MC^3*MZ^2*s*SW^4 + 245760*CW^4*MB^11*MC^3*MZ^2*s*
    SW^4 - 245760*cos^2*CW^4*MB^11*MC^3*MZ^2*s*SW^4 - 
   56832*CW^4*GammaZ^2*MB^8*MC^4*MZ^2*s*SW^4 - 23040*cos^2*CW^4*GammaZ^2*MB^8*
    MC^4*MZ^2*s*SW^4 - 224256*CW^2*MB^10*MC^4*MZ^2*s*SW^4 + 
   224256*cos^2*CW^2*MB^10*MC^4*MZ^2*s*SW^4 + 233472*CW^4*MB^10*MC^4*MZ^2*s*
    SW^4 - 233472*cos^2*CW^4*MB^10*MC^4*MZ^2*s*SW^4 - 
   73728*CW^4*GammaZ^2*MB^7*MC^5*MZ^2*s*SW^4 - 61440*cos^2*CW^4*GammaZ^2*MB^7*
    MC^5*MZ^2*s*SW^4 - 313344*CW^2*MB^9*MC^5*MZ^2*s*SW^4 + 
   313344*cos^2*CW^2*MB^9*MC^5*MZ^2*s*SW^4 + 368640*CW^4*MB^9*MC^5*MZ^2*s*
    SW^4 - 368640*cos^2*CW^4*MB^9*MC^5*MZ^2*s*SW^4 - 
   82944*CW^4*GammaZ^2*MB^6*MC^6*MZ^2*s*SW^4 - 91136*cos^2*CW^4*GammaZ^2*MB^6*
    MC^6*MZ^2*s*SW^4 - 611328*CW^2*MB^8*MC^6*MZ^2*s*SW^4 + 
   611328*cos^2*CW^2*MB^8*MC^6*MZ^2*s*SW^4 + 749568*CW^4*MB^8*MC^6*MZ^2*s*
    SW^4 - 749568*cos^2*CW^4*MB^8*MC^6*MZ^2*s*SW^4 - 
   98304*CW^4*GammaZ^2*MB^5*MC^7*MZ^2*s*SW^4 - 73728*cos^2*CW^4*GammaZ^2*MB^5*
    MC^7*MZ^2*s*SW^4 - 798720*CW^2*MB^7*MC^7*MZ^2*s*SW^4 + 
   798720*cos^2*CW^2*MB^7*MC^7*MZ^2*s*SW^4 + 983040*CW^4*MB^7*MC^7*MZ^2*s*
    SW^4 - 983040*cos^2*CW^4*MB^7*MC^7*MZ^2*s*SW^4 - 
   122880*CW^4*GammaZ^2*MB^4*MC^8*MZ^2*s*SW^4 - 49152*cos^2*CW^4*GammaZ^2*
    MB^4*MC^8*MZ^2*s*SW^4 - 629760*CW^2*MB^6*MC^8*MZ^2*s*SW^4 + 
   629760*cos^2*CW^2*MB^6*MC^8*MZ^2*s*SW^4 + 786432*CW^4*MB^6*MC^8*MZ^2*s*
    SW^4 - 786432*cos^2*CW^4*MB^6*MC^8*MZ^2*s*SW^4 - 
   114688*CW^4*GammaZ^2*MB^3*MC^9*MZ^2*s*SW^4 - 57344*cos^2*CW^4*GammaZ^2*
    MB^3*MC^9*MZ^2*s*SW^4 - 423936*CW^2*MB^5*MC^9*MZ^2*s*SW^4 + 
   423936*cos^2*CW^2*MB^5*MC^9*MZ^2*s*SW^4 + 589824*CW^4*MB^5*MC^9*MZ^2*s*
    SW^4 - 589824*cos^2*CW^4*MB^5*MC^9*MZ^2*s*SW^4 - 
   57344*CW^4*GammaZ^2*MB^2*MC^10*MZ^2*s*SW^4 - 65536*cos^2*CW^4*GammaZ^2*
    MB^2*MC^10*MZ^2*s*SW^4 - 500736*CW^2*MB^4*MC^10*MZ^2*s*SW^4 + 
   500736*cos^2*CW^2*MB^4*MC^10*MZ^2*s*SW^4 + 786432*CW^4*MB^4*MC^10*MZ^2*s*
    SW^4 - 786432*cos^2*CW^4*MB^4*MC^10*MZ^2*s*SW^4 - 
   8192*CW^4*GammaZ^2*MB*MC^11*MZ^2*s*SW^4 - 40960*cos^2*CW^4*GammaZ^2*MB*
    MC^11*MZ^2*s*SW^4 - 614400*CW^2*MB^3*MC^11*MZ^2*s*SW^4 + 
   614400*cos^2*CW^2*MB^3*MC^11*MZ^2*s*SW^4 + 983040*CW^4*MB^3*MC^11*MZ^2*s*
    SW^4 - 983040*cos^2*CW^4*MB^3*MC^11*MZ^2*s*SW^4 + 
   2048*CW^4*GammaZ^2*MC^12*MZ^2*s*SW^4 - 10240*cos^2*CW^4*GammaZ^2*MC^12*
    MZ^2*s*SW^4 - 460800*CW^2*MB^2*MC^12*MZ^2*s*SW^4 + 
   460800*cos^2*CW^2*MB^2*MC^12*MZ^2*s*SW^4 + 737280*CW^4*MB^2*MC^12*MZ^2*s*
    SW^4 - 737280*cos^2*CW^4*MB^2*MC^12*MZ^2*s*SW^4 - 
   184320*CW^2*MB*MC^13*MZ^2*s*SW^4 + 184320*cos^2*CW^2*MB*MC^13*MZ^2*s*
    SW^4 + 294912*CW^4*MB*MC^13*MZ^2*s*SW^4 - 294912*cos^2*CW^4*MB*MC^13*MZ^2*
    s*SW^4 - 30720*CW^2*MC^14*MZ^2*s*SW^4 + 30720*cos^2*CW^2*MC^14*MZ^2*s*
    SW^4 + 49152*CW^4*MC^14*MZ^2*s*SW^4 - 49152*cos^2*CW^4*MC^14*MZ^2*s*
    SW^4 + 512*CW^4*MB^12*MZ^4*s*SW^4 - 2560*cos^2*CW^4*MB^12*MZ^4*s*SW^4 - 
   2048*CW^4*MB^11*MC*MZ^4*s*SW^4 - 10240*cos^2*CW^4*MB^11*MC*MZ^4*s*SW^4 - 
   14336*CW^4*MB^10*MC^2*MZ^4*s*SW^4 - 16384*cos^2*CW^4*MB^10*MC^2*MZ^4*s*
    SW^4 - 34816*CW^4*MB^9*MC^3*MZ^4*s*SW^4 - 14336*cos^2*CW^4*MB^9*MC^3*MZ^4*
    s*SW^4 - 56832*CW^4*MB^8*MC^4*MZ^4*s*SW^4 - 23040*cos^2*CW^4*MB^8*MC^4*
    MZ^4*s*SW^4 - 73728*CW^4*MB^7*MC^5*MZ^4*s*SW^4 - 
   61440*cos^2*CW^4*MB^7*MC^5*MZ^4*s*SW^4 - 82944*CW^4*MB^6*MC^6*MZ^4*s*
    SW^4 - 91136*cos^2*CW^4*MB^6*MC^6*MZ^4*s*SW^4 - 
   98304*CW^4*MB^5*MC^7*MZ^4*s*SW^4 - 73728*cos^2*CW^4*MB^5*MC^7*MZ^4*s*
    SW^4 - 122880*CW^4*MB^4*MC^8*MZ^4*s*SW^4 - 49152*cos^2*CW^4*MB^4*MC^8*
    MZ^4*s*SW^4 - 114688*CW^4*MB^3*MC^9*MZ^4*s*SW^4 - 
   57344*cos^2*CW^4*MB^3*MC^9*MZ^4*s*SW^4 - 57344*CW^4*MB^2*MC^10*MZ^4*s*
    SW^4 - 65536*cos^2*CW^4*MB^2*MC^10*MZ^4*s*SW^4 - 
   8192*CW^4*MB*MC^11*MZ^4*s*SW^4 - 40960*cos^2*CW^4*MB*MC^11*MZ^4*s*SW^4 + 
   2048*CW^4*MC^12*MZ^4*s*SW^4 - 10240*cos^2*CW^4*MC^12*MZ^4*s*SW^4 - 
   6528*MB^14*s^2*SW^4 + 11136*cos^2*MB^14*s^2*SW^4 + 
   12288*CW^2*MB^14*s^2*SW^4 - 12288*cos^2*CW^2*MB^14*s^2*SW^4 - 
   6144*CW^4*MB^14*s^2*SW^4 + 6144*cos^2*CW^4*MB^14*s^2*SW^4 - 
   39168*MB^13*MC*s^2*SW^4 + 66816*cos^2*MB^13*MC*s^2*SW^4 + 
   73728*CW^2*MB^13*MC*s^2*SW^4 - 73728*cos^2*CW^2*MB^13*MC*s^2*SW^4 - 
   36864*CW^4*MB^13*MC*s^2*SW^4 + 36864*cos^2*CW^4*MB^13*MC*s^2*SW^4 - 
   97920*MB^12*MC^2*s^2*SW^4 + 167040*cos^2*MB^12*MC^2*s^2*SW^4 + 
   184320*CW^2*MB^12*MC^2*s^2*SW^4 - 184320*cos^2*CW^2*MB^12*MC^2*s^2*SW^4 - 
   92160*CW^4*MB^12*MC^2*s^2*SW^4 + 92160*cos^2*CW^4*MB^12*MC^2*s^2*SW^4 - 
   130560*MB^11*MC^3*s^2*SW^4 + 222720*cos^2*MB^11*MC^3*s^2*SW^4 + 
   245760*CW^2*MB^11*MC^3*s^2*SW^4 - 245760*cos^2*CW^2*MB^11*MC^3*s^2*SW^4 - 
   122880*CW^4*MB^11*MC^3*s^2*SW^4 + 122880*cos^2*CW^4*MB^11*MC^3*s^2*SW^4 - 
   126336*MB^10*MC^4*s^2*SW^4 + 186240*cos^2*MB^10*MC^4*s^2*SW^4 + 
   224256*CW^2*MB^10*MC^4*s^2*SW^4 - 224256*cos^2*CW^2*MB^10*MC^4*s^2*SW^4 - 
   116736*CW^4*MB^10*MC^4*s^2*SW^4 + 116736*cos^2*CW^4*MB^10*MC^4*s^2*SW^4 - 
   209664*MB^9*MC^5*s^2*SW^4 + 182016*cos^2*MB^9*MC^5*s^2*SW^4 + 
   313344*CW^2*MB^9*MC^5*s^2*SW^4 - 313344*cos^2*CW^2*MB^9*MC^5*s^2*SW^4 - 
   184320*CW^4*MB^9*MC^5*s^2*SW^4 + 184320*cos^2*CW^4*MB^9*MC^5*s^2*SW^4 - 
   432768*MB^8*MC^6*s^2*SW^4 + 299136*cos^2*MB^8*MC^6*s^2*SW^4 + 
   611328*CW^2*MB^8*MC^6*s^2*SW^4 - 611328*cos^2*CW^2*MB^8*MC^6*s^2*SW^4 - 
   374784*CW^4*MB^8*MC^6*s^2*SW^4 + 374784*cos^2*CW^4*MB^8*MC^6*s^2*SW^4 - 
   568320*MB^7*MC^7*s^2*SW^4 + 384000*cos^2*MB^7*MC^7*s^2*SW^4 + 
   798720*CW^2*MB^7*MC^7*s^2*SW^4 - 798720*cos^2*CW^2*MB^7*MC^7*s^2*SW^4 - 
   491520*CW^4*MB^7*MC^7*s^2*SW^4 + 491520*cos^2*CW^4*MB^7*MC^7*s^2*SW^4 - 
   439680*MB^6*MC^8*s^2*SW^4 + 306048*cos^2*MB^6*MC^8*s^2*SW^4 + 
   629760*CW^2*MB^6*MC^8*s^2*SW^4 - 629760*cos^2*CW^2*MB^6*MC^8*s^2*SW^4 - 
   393216*CW^4*MB^6*MC^8*s^2*SW^4 + 393216*cos^2*CW^4*MB^6*MC^8*s^2*SW^4 - 
   251136*MB^5*MC^9*s^2*SW^4 + 223488*cos^2*MB^5*MC^9*s^2*SW^4 + 
   423936*CW^2*MB^5*MC^9*s^2*SW^4 - 423936*cos^2*CW^2*MB^5*MC^9*s^2*SW^4 - 
   294912*CW^4*MB^5*MC^9*s^2*SW^4 + 294912*cos^2*CW^4*MB^5*MC^9*s^2*SW^4 - 
   230016*MB^4*MC^10*s^2*SW^4 + 289920*cos^2*MB^4*MC^10*s^2*SW^4 + 
   500736*CW^2*MB^4*MC^10*s^2*SW^4 - 500736*cos^2*CW^2*MB^4*MC^10*s^2*SW^4 - 
   393216*CW^4*MB^4*MC^10*s^2*SW^4 + 393216*cos^2*CW^4*MB^4*MC^10*s^2*SW^4 - 
   268800*MB^3*MC^11*s^2*SW^4 + 360960*cos^2*MB^3*MC^11*s^2*SW^4 + 
   614400*CW^2*MB^3*MC^11*s^2*SW^4 - 614400*cos^2*CW^2*MB^3*MC^11*s^2*SW^4 - 
   491520*CW^4*MB^3*MC^11*s^2*SW^4 + 491520*cos^2*CW^4*MB^3*MC^11*s^2*SW^4 - 
   201600*MB^2*MC^12*s^2*SW^4 + 270720*cos^2*MB^2*MC^12*s^2*SW^4 + 
   460800*CW^2*MB^2*MC^12*s^2*SW^4 - 460800*cos^2*CW^2*MB^2*MC^12*s^2*SW^4 - 
   368640*CW^4*MB^2*MC^12*s^2*SW^4 + 368640*cos^2*CW^4*MB^2*MC^12*s^2*SW^4 - 
   80640*MB*MC^13*s^2*SW^4 + 108288*cos^2*MB*MC^13*s^2*SW^4 + 
   184320*CW^2*MB*MC^13*s^2*SW^4 - 184320*cos^2*CW^2*MB*MC^13*s^2*SW^4 - 
   147456*CW^4*MB*MC^13*s^2*SW^4 + 147456*cos^2*CW^4*MB*MC^13*s^2*SW^4 - 
   13440*MC^14*s^2*SW^4 + 18048*cos^2*MC^14*s^2*SW^4 + 
   30720*CW^2*MC^14*s^2*SW^4 - 30720*cos^2*CW^2*MC^14*s^2*SW^4 - 
   24576*CW^4*MC^14*s^2*SW^4 + 24576*cos^2*CW^4*MC^14*s^2*SW^4 + 
   256*CW^4*GammaZ^2*MB^10*MZ^2*s^2*SW^4 + 256*cos^2*CW^4*GammaZ^2*MB^10*MZ^2*
    s^2*SW^4 + 1024*CW^2*MB^12*MZ^2*s^2*SW^4 - 5120*cos^2*CW^2*MB^12*MZ^2*s^2*
    SW^4 - 1024*CW^4*MB^12*MZ^2*s^2*SW^4 + 5120*cos^2*CW^4*MB^12*MZ^2*s^2*
    SW^4 + 1536*CW^4*GammaZ^2*MB^9*MC*MZ^2*s^2*SW^4 + 
   512*cos^2*CW^4*GammaZ^2*MB^9*MC*MZ^2*s^2*SW^4 - 
   4096*CW^2*MB^11*MC*MZ^2*s^2*SW^4 - 20480*cos^2*CW^2*MB^11*MC*MZ^2*s^2*
    SW^4 + 4096*CW^4*MB^11*MC*MZ^2*s^2*SW^4 + 20480*cos^2*CW^4*MB^11*MC*MZ^2*
    s^2*SW^4 + 2048*CW^4*GammaZ^2*MB^8*MC^2*MZ^2*s^2*SW^4 + 
   1024*cos^2*CW^4*GammaZ^2*MB^8*MC^2*MZ^2*s^2*SW^4 - 
   28672*CW^2*MB^10*MC^2*MZ^2*s^2*SW^4 - 32768*cos^2*CW^2*MB^10*MC^2*MZ^2*s^2*
    SW^4 + 28672*CW^4*MB^10*MC^2*MZ^2*s^2*SW^4 + 32768*cos^2*CW^4*MB^10*MC^2*
    MZ^2*s^2*SW^4 + 2560*CW^4*GammaZ^2*MB^7*MC^3*MZ^2*s^2*SW^4 + 
   1536*cos^2*CW^4*GammaZ^2*MB^7*MC^3*MZ^2*s^2*SW^4 - 
   66560*CW^2*MB^9*MC^3*MZ^2*s^2*SW^4 - 28672*cos^2*CW^2*MB^9*MC^3*MZ^2*s^2*
    SW^4 + 69632*CW^4*MB^9*MC^3*MZ^2*s^2*SW^4 + 28672*cos^2*CW^4*MB^9*MC^3*
    MZ^2*s^2*SW^4 + 3840*CW^4*GammaZ^2*MB^6*MC^4*MZ^2*s^2*SW^4 + 
   4864*cos^2*CW^4*GammaZ^2*MB^6*MC^4*MZ^2*s^2*SW^4 - 
   100608*CW^2*MB^8*MC^4*MZ^2*s^2*SW^4 - 40704*cos^2*CW^2*MB^8*MC^4*MZ^2*s^2*
    SW^4 + 113664*CW^4*MB^8*MC^4*MZ^2*s^2*SW^4 + 46080*cos^2*CW^4*MB^8*MC^4*
    MZ^2*s^2*SW^4 + 4096*CW^4*GammaZ^2*MB^5*MC^5*MZ^2*s^2*SW^4 + 
   8192*cos^2*CW^4*GammaZ^2*MB^5*MC^5*MZ^2*s^2*SW^4 - 
   122880*CW^2*MB^7*MC^5*MZ^2*s^2*SW^4 - 101376*cos^2*CW^2*MB^7*MC^5*MZ^2*s^2*
    SW^4 + 147456*CW^4*MB^7*MC^5*MZ^2*s^2*SW^4 + 122880*cos^2*CW^4*MB^7*MC^5*
    MZ^2*s^2*SW^4 + 3072*CW^4*GammaZ^2*MB^4*MC^6*MZ^2*s^2*SW^4 + 
   7168*cos^2*CW^4*GammaZ^2*MB^4*MC^6*MZ^2*s^2*SW^4 - 
   133632*CW^2*MB^6*MC^6*MZ^2*s^2*SW^4 - 146944*cos^2*CW^2*MB^6*MC^6*MZ^2*s^2*
    SW^4 + 165888*CW^4*MB^6*MC^6*MZ^2*s^2*SW^4 + 182272*cos^2*CW^4*MB^6*MC^6*
    MZ^2*s^2*SW^4 + 4096*CW^4*GammaZ^2*MB^3*MC^7*MZ^2*s^2*SW^4 + 
   6144*cos^2*CW^4*GammaZ^2*MB^3*MC^7*MZ^2*s^2*SW^4 - 
   147456*CW^2*MB^5*MC^7*MZ^2*s^2*SW^4 - 113664*cos^2*CW^2*MB^5*MC^7*MZ^2*s^2*
    SW^4 + 196608*CW^4*MB^5*MC^7*MZ^2*s^2*SW^4 + 147456*cos^2*CW^4*MB^5*MC^7*
    MZ^2*s^2*SW^4 + 8192*CW^4*GammaZ^2*MB^2*MC^8*MZ^2*s^2*SW^4 + 
   4096*cos^2*CW^4*GammaZ^2*MB^2*MC^8*MZ^2*s^2*SW^4 - 
   166656*CW^2*MB^4*MC^8*MZ^2*s^2*SW^4 - 66816*cos^2*CW^2*MB^4*MC^8*MZ^2*s^2*
    SW^4 + 245760*CW^4*MB^4*MC^8*MZ^2*s^2*SW^4 + 98304*cos^2*CW^4*MB^4*MC^8*
    MZ^2*s^2*SW^4 + 6144*CW^4*GammaZ^2*MB*MC^9*MZ^2*s^2*SW^4 + 
   2048*cos^2*CW^4*GammaZ^2*MB*MC^9*MZ^2*s^2*SW^4 - 
   146432*CW^2*MB^3*MC^9*MZ^2*s^2*SW^4 - 71680*cos^2*CW^2*MB^3*MC^9*MZ^2*s^2*
    SW^4 + 229376*CW^4*MB^3*MC^9*MZ^2*s^2*SW^4 + 114688*cos^2*CW^4*MB^3*MC^9*
    MZ^2*s^2*SW^4 + 1024*CW^4*GammaZ^2*MC^10*MZ^2*s^2*SW^4 + 
   1024*cos^2*CW^4*GammaZ^2*MC^10*MZ^2*s^2*SW^4 - 
   71680*CW^2*MB^2*MC^10*MZ^2*s^2*SW^4 - 81920*cos^2*CW^2*MB^2*MC^10*MZ^2*s^2*
    SW^4 + 114688*CW^4*MB^2*MC^10*MZ^2*s^2*SW^4 + 
   131072*cos^2*CW^4*MB^2*MC^10*MZ^2*s^2*SW^4 - 10240*CW^2*MB*MC^11*MZ^2*s^2*
    SW^4 - 51200*cos^2*CW^2*MB*MC^11*MZ^2*s^2*SW^4 + 
   16384*CW^4*MB*MC^11*MZ^2*s^2*SW^4 + 81920*cos^2*CW^4*MB*MC^11*MZ^2*s^2*
    SW^4 + 2560*CW^2*MC^12*MZ^2*s^2*SW^4 - 12800*cos^2*CW^2*MC^12*MZ^2*s^2*
    SW^4 - 4096*CW^4*MC^12*MZ^2*s^2*SW^4 + 20480*cos^2*CW^4*MC^12*MZ^2*s^2*
    SW^4 + 256*CW^4*MB^10*MZ^4*s^2*SW^4 + 256*cos^2*CW^4*MB^10*MZ^4*s^2*
    SW^4 + 1536*CW^4*MB^9*MC*MZ^4*s^2*SW^4 + 512*cos^2*CW^4*MB^9*MC*MZ^4*s^2*
    SW^4 + 2048*CW^4*MB^8*MC^2*MZ^4*s^2*SW^4 + 1024*cos^2*CW^4*MB^8*MC^2*MZ^4*
    s^2*SW^4 + 2560*CW^4*MB^7*MC^3*MZ^4*s^2*SW^4 + 
   1536*cos^2*CW^4*MB^7*MC^3*MZ^4*s^2*SW^4 + 3840*CW^4*MB^6*MC^4*MZ^4*s^2*
    SW^4 + 4864*cos^2*CW^4*MB^6*MC^4*MZ^4*s^2*SW^4 + 
   4096*CW^4*MB^5*MC^5*MZ^4*s^2*SW^4 + 8192*cos^2*CW^4*MB^5*MC^5*MZ^4*s^2*
    SW^4 + 3072*CW^4*MB^4*MC^6*MZ^4*s^2*SW^4 + 7168*cos^2*CW^4*MB^4*MC^6*MZ^4*
    s^2*SW^4 + 4096*CW^4*MB^3*MC^7*MZ^4*s^2*SW^4 + 
   6144*cos^2*CW^4*MB^3*MC^7*MZ^4*s^2*SW^4 + 8192*CW^4*MB^2*MC^8*MZ^4*s^2*
    SW^4 + 4096*cos^2*CW^4*MB^2*MC^8*MZ^4*s^2*SW^4 + 
   6144*CW^4*MB*MC^9*MZ^4*s^2*SW^4 + 2048*cos^2*CW^4*MB*MC^9*MZ^4*s^2*SW^4 + 
   1024*CW^4*MC^10*MZ^4*s^2*SW^4 + 1024*cos^2*CW^4*MC^10*MZ^4*s^2*SW^4 - 
   416*MB^12*s^3*SW^4 - 4832*cos^2*MB^12*s^3*SW^4 - 
   1024*CW^2*MB^12*s^3*SW^4 + 5120*cos^2*CW^2*MB^12*s^3*SW^4 + 
   512*CW^4*MB^12*s^3*SW^4 - 2560*cos^2*CW^4*MB^12*s^3*SW^4 - 
   7552*MB^11*MC*s^3*SW^4 - 19328*cos^2*MB^11*MC*s^3*SW^4 + 
   4096*CW^2*MB^11*MC*s^3*SW^4 + 20480*cos^2*CW^2*MB^11*MC*s^3*SW^4 - 
   2048*CW^4*MB^11*MC*s^3*SW^4 - 10240*cos^2*CW^4*MB^11*MC*s^3*SW^4 - 
   27520*MB^10*MC^2*s^3*SW^4 - 30464*cos^2*MB^10*MC^2*s^3*SW^4 + 
   28672*CW^2*MB^10*MC^2*s^3*SW^4 + 32768*cos^2*CW^2*MB^10*MC^2*s^3*SW^4 - 
   14336*CW^4*MB^10*MC^2*s^3*SW^4 - 16384*cos^2*CW^4*MB^10*MC^2*s^3*SW^4 - 
   50816*MB^9*MC^3*s^3*SW^4 - 25216*cos^2*MB^9*MC^3*s^3*SW^4 + 
   66560*CW^2*MB^9*MC^3*s^3*SW^4 + 28672*cos^2*CW^2*MB^9*MC^3*s^3*SW^4 - 
   34816*CW^4*MB^9*MC^3*s^3*SW^4 - 14336*cos^2*CW^4*MB^9*MC^3*s^3*SW^4 - 
   64224*MB^8*MC^4*s^3*SW^4 - 25248*cos^2*MB^8*MC^4*s^3*SW^4 + 
   100608*CW^2*MB^8*MC^4*s^3*SW^4 + 40704*cos^2*CW^2*MB^8*MC^4*s^3*SW^4 - 
   56832*CW^4*MB^8*MC^4*s^3*SW^4 - 23040*cos^2*CW^4*MB^8*MC^4*s^3*SW^4 - 
   66048*MB^7*MC^5*s^3*SW^4 - 52224*cos^2*MB^7*MC^5*s^3*SW^4 + 
   122880*CW^2*MB^7*MC^5*s^3*SW^4 + 101376*cos^2*CW^2*MB^7*MC^5*s^3*SW^4 - 
   73728*CW^4*MB^7*MC^5*s^3*SW^4 - 61440*cos^2*CW^4*MB^7*MC^5*s^3*SW^4 - 
   65664*MB^6*MC^6*s^3*SW^4 - 73600*cos^2*MB^6*MC^6*s^3*SW^4 + 
   133632*CW^2*MB^6*MC^6*s^3*SW^4 + 146944*cos^2*CW^2*MB^6*MC^6*s^3*SW^4 - 
   82944*CW^4*MB^6*MC^6*s^3*SW^4 - 91136*cos^2*CW^4*MB^6*MC^6*s^3*SW^4 - 
   75264*MB^5*MC^7*s^3*SW^4 - 56832*cos^2*MB^5*MC^7*s^3*SW^4 + 
   147456*CW^2*MB^5*MC^7*s^3*SW^4 + 113664*cos^2*CW^2*MB^5*MC^7*s^3*SW^4 - 
   98304*CW^4*MB^5*MC^7*s^3*SW^4 - 73728*cos^2*CW^4*MB^5*MC^7*s^3*SW^4 - 
   88992*MB^4*MC^8*s^3*SW^4 - 35040*cos^2*MB^4*MC^8*s^3*SW^4 + 
   166656*CW^2*MB^4*MC^8*s^3*SW^4 + 66816*cos^2*CW^2*MB^4*MC^8*s^3*SW^4 - 
   122880*CW^4*MB^4*MC^8*s^3*SW^4 - 49152*cos^2*CW^4*MB^4*MC^8*s^3*SW^4 - 
   80768*MB^3*MC^9*s^3*SW^4 - 41344*cos^2*MB^3*MC^9*s^3*SW^4 + 
   146432*CW^2*MB^3*MC^9*s^3*SW^4 + 71680*cos^2*CW^2*MB^3*MC^9*s^3*SW^4 - 
   114688*CW^4*MB^3*MC^9*s^3*SW^4 - 57344*cos^2*CW^4*MB^3*MC^9*s^3*SW^4 - 
   43648*MB^2*MC^10*s^3*SW^4 - 48896*cos^2*MB^2*MC^10*s^3*SW^4 + 
   71680*CW^2*MB^2*MC^10*s^3*SW^4 + 81920*cos^2*CW^2*MB^2*MC^10*s^3*SW^4 - 
   57344*CW^4*MB^2*MC^10*s^3*SW^4 - 65536*cos^2*CW^4*MB^2*MC^10*s^3*SW^4 - 
   9856*MB*MC^11*s^3*SW^4 - 30848*cos^2*MB*MC^11*s^3*SW^4 + 
   10240*CW^2*MB*MC^11*s^3*SW^4 + 51200*cos^2*CW^2*MB*MC^11*s^3*SW^4 - 
   8192*CW^4*MB*MC^11*s^3*SW^4 - 40960*cos^2*CW^4*MB*MC^11*s^3*SW^4 + 
   160*MC^12*s^3*SW^4 - 7712*cos^2*MC^12*s^3*SW^4 - 
   2560*CW^2*MC^12*s^3*SW^4 + 12800*cos^2*CW^2*MC^12*s^3*SW^4 + 
   2048*CW^4*MC^12*s^3*SW^4 - 10240*cos^2*CW^4*MC^12*s^3*SW^4 + 
   512*CW^2*MB^10*MZ^2*s^3*SW^4 + 512*cos^2*CW^2*MB^10*MZ^2*s^3*SW^4 - 
   512*CW^4*MB^10*MZ^2*s^3*SW^4 - 512*cos^2*CW^4*MB^10*MZ^2*s^3*SW^4 + 
   3072*CW^2*MB^9*MC*MZ^2*s^3*SW^4 + 1024*cos^2*CW^2*MB^9*MC*MZ^2*s^3*SW^4 - 
   3072*CW^4*MB^9*MC*MZ^2*s^3*SW^4 - 1024*cos^2*CW^4*MB^9*MC*MZ^2*s^3*SW^4 + 
   128*CW^4*GammaZ^2*MB^6*MC^2*MZ^2*s^3*SW^4 - 128*cos^2*CW^4*GammaZ^2*MB^6*
    MC^2*MZ^2*s^3*SW^4 + 4096*CW^2*MB^8*MC^2*MZ^2*s^3*SW^4 + 
   2048*cos^2*CW^2*MB^8*MC^2*MZ^2*s^3*SW^4 - 4096*CW^4*MB^8*MC^2*MZ^2*s^3*
    SW^4 - 2048*cos^2*CW^4*MB^8*MC^2*MZ^2*s^3*SW^4 + 
   4352*CW^2*MB^7*MC^3*MZ^2*s^3*SW^4 + 3072*cos^2*CW^2*MB^7*MC^3*MZ^2*s^3*
    SW^4 - 5120*CW^4*MB^7*MC^3*MZ^2*s^3*SW^4 - 3072*cos^2*CW^4*MB^7*MC^3*MZ^2*
    s^3*SW^4 + 512*CW^4*GammaZ^2*MB^4*MC^4*MZ^2*s^3*SW^4 - 
   512*cos^2*CW^4*GammaZ^2*MB^4*MC^4*MZ^2*s^3*SW^4 + 
   6144*CW^2*MB^6*MC^4*MZ^2*s^3*SW^4 + 8192*cos^2*CW^2*MB^6*MC^4*MZ^2*s^3*
    SW^4 - 7680*CW^4*MB^6*MC^4*MZ^2*s^3*SW^4 - 9728*cos^2*CW^4*MB^6*MC^4*MZ^2*
    s^3*SW^4 + 6656*CW^2*MB^5*MC^5*MZ^2*s^3*SW^4 + 
   13312*cos^2*CW^2*MB^5*MC^5*MZ^2*s^3*SW^4 - 8192*CW^4*MB^5*MC^5*MZ^2*s^3*
    SW^4 - 16384*cos^2*CW^4*MB^5*MC^5*MZ^2*s^3*SW^4 + 
   512*CW^4*GammaZ^2*MB^2*MC^6*MZ^2*s^3*SW^4 - 512*cos^2*CW^4*GammaZ^2*MB^2*
    MC^6*MZ^2*s^3*SW^4 + 5376*CW^2*MB^4*MC^6*MZ^2*s^3*SW^4 + 
   10496*cos^2*CW^2*MB^4*MC^6*MZ^2*s^3*SW^4 - 6144*CW^4*MB^4*MC^6*MZ^2*s^3*
    SW^4 - 14336*cos^2*CW^4*MB^4*MC^6*MZ^2*s^3*SW^4 + 
   5888*CW^2*MB^3*MC^7*MZ^2*s^3*SW^4 + 7680*cos^2*CW^2*MB^3*MC^7*MZ^2*s^3*
    SW^4 - 8192*CW^4*MB^3*MC^7*MZ^2*s^3*SW^4 - 12288*cos^2*CW^4*MB^3*MC^7*
    MZ^2*s^3*SW^4 + 10240*CW^2*MB^2*MC^8*MZ^2*s^3*SW^4 + 
   5120*cos^2*CW^2*MB^2*MC^8*MZ^2*s^3*SW^4 - 16384*CW^4*MB^2*MC^8*MZ^2*s^3*
    SW^4 - 8192*cos^2*CW^4*MB^2*MC^8*MZ^2*s^3*SW^4 + 
   7680*CW^2*MB*MC^9*MZ^2*s^3*SW^4 + 2560*cos^2*CW^2*MB*MC^9*MZ^2*s^3*SW^4 - 
   12288*CW^4*MB*MC^9*MZ^2*s^3*SW^4 - 4096*cos^2*CW^4*MB*MC^9*MZ^2*s^3*SW^4 + 
   1280*CW^2*MC^10*MZ^2*s^3*SW^4 + 1280*cos^2*CW^2*MC^10*MZ^2*s^3*SW^4 - 
   2048*CW^4*MC^10*MZ^2*s^3*SW^4 - 2048*cos^2*CW^4*MC^10*MZ^2*s^3*SW^4 + 
   128*CW^4*MB^6*MC^2*MZ^4*s^3*SW^4 - 128*cos^2*CW^4*MB^6*MC^2*MZ^4*s^3*
    SW^4 + 512*CW^4*MB^4*MC^4*MZ^4*s^3*SW^4 - 512*cos^2*CW^4*MB^4*MC^4*MZ^4*
    s^3*SW^4 + 512*CW^4*MB^2*MC^6*MZ^4*s^3*SW^4 - 
   512*cos^2*CW^4*MB^2*MC^6*MZ^4*s^3*SW^4 + 512*MB^10*s^4*SW^4 + 
   512*cos^2*MB^10*s^4*SW^4 - 512*CW^2*MB^10*s^4*SW^4 - 
   512*cos^2*CW^2*MB^10*s^4*SW^4 + 256*CW^4*MB^10*s^4*SW^4 + 
   256*cos^2*CW^4*MB^10*s^4*SW^4 + 2496*MB^9*MC*s^4*SW^4 + 
   1024*cos^2*MB^9*MC*s^4*SW^4 - 3072*CW^2*MB^9*MC*s^4*SW^4 - 
   1024*cos^2*CW^2*MB^9*MC*s^4*SW^4 + 1536*CW^4*MB^9*MC*s^4*SW^4 + 
   512*cos^2*CW^4*MB^9*MC*s^4*SW^4 + 3088*MB^8*MC^2*s^4*SW^4 + 
   1616*cos^2*MB^8*MC^2*s^4*SW^4 - 4096*CW^2*MB^8*MC^2*s^4*SW^4 - 
   2048*cos^2*CW^2*MB^8*MC^2*s^4*SW^4 + 2048*CW^4*MB^8*MC^2*s^4*SW^4 + 
   1024*cos^2*CW^4*MB^8*MC^2*s^4*SW^4 + 2720*MB^7*MC^3*s^4*SW^4 + 
   2208*cos^2*MB^7*MC^3*s^4*SW^4 - 4352*CW^2*MB^7*MC^3*s^4*SW^4 - 
   3072*cos^2*CW^2*MB^7*MC^3*s^4*SW^4 + 2560*CW^4*MB^7*MC^3*s^4*SW^4 + 
   1536*cos^2*CW^4*MB^7*MC^3*s^4*SW^4 + 3312*MB^6*MC^4*s^4*SW^4 + 
   4784*cos^2*MB^6*MC^4*s^4*SW^4 - 6144*CW^2*MB^6*MC^4*s^4*SW^4 - 
   8192*cos^2*CW^2*MB^6*MC^4*s^4*SW^4 + 3840*CW^4*MB^6*MC^4*s^4*SW^4 + 
   4864*cos^2*CW^4*MB^6*MC^4*s^4*SW^4 + 3392*MB^5*MC^5*s^4*SW^4 + 
   7360*cos^2*MB^5*MC^5*s^4*SW^4 - 6656*CW^2*MB^5*MC^5*s^4*SW^4 - 
   13312*cos^2*CW^2*MB^5*MC^5*s^4*SW^4 + 4096*CW^4*MB^5*MC^5*s^4*SW^4 + 
   8192*cos^2*CW^4*MB^5*MC^5*s^4*SW^4 + 3024*MB^4*MC^6*s^4*SW^4 + 
   5648*cos^2*MB^4*MC^6*s^4*SW^4 - 5376*CW^2*MB^4*MC^6*s^4*SW^4 - 
   10496*cos^2*CW^2*MB^4*MC^6*s^4*SW^4 + 3072*CW^4*MB^4*MC^6*s^4*SW^4 + 
   7168*cos^2*CW^4*MB^4*MC^6*s^4*SW^4 + 3296*MB^3*MC^7*s^4*SW^4 + 
   3936*cos^2*MB^3*MC^7*s^4*SW^4 - 5888*CW^2*MB^3*MC^7*s^4*SW^4 - 
   7680*cos^2*CW^2*MB^3*MC^7*s^4*SW^4 + 4096*CW^4*MB^3*MC^7*s^4*SW^4 + 
   6144*cos^2*CW^4*MB^3*MC^7*s^4*SW^4 + 5392*MB^2*MC^8*s^4*SW^4 + 
   2768*cos^2*MB^2*MC^8*s^4*SW^4 - 10240*CW^2*MB^2*MC^8*s^4*SW^4 - 
   5120*cos^2*CW^2*MB^2*MC^8*s^4*SW^4 + 8192*CW^4*MB^2*MC^8*s^4*SW^4 + 
   4096*cos^2*CW^4*MB^2*MC^8*s^4*SW^4 + 4224*MB*MC^9*s^4*SW^4 + 
   1600*cos^2*MB*MC^9*s^4*SW^4 - 7680*CW^2*MB*MC^9*s^4*SW^4 - 
   2560*cos^2*CW^2*MB*MC^9*s^4*SW^4 + 6144*CW^4*MB*MC^9*s^4*SW^4 + 
   2048*cos^2*CW^4*MB*MC^9*s^4*SW^4 + 800*MC^10*s^4*SW^4 + 
   800*cos^2*MC^10*s^4*SW^4 - 1280*CW^2*MC^10*s^4*SW^4 - 
   1280*cos^2*CW^2*MC^10*s^4*SW^4 + 1024*CW^4*MC^10*s^4*SW^4 + 
   1024*cos^2*CW^4*MC^10*s^4*SW^4 + 256*CW^2*MB^6*MC^2*MZ^2*s^4*SW^4 - 
   256*cos^2*CW^2*MB^6*MC^2*MZ^2*s^4*SW^4 - 256*CW^4*MB^6*MC^2*MZ^2*s^4*
    SW^4 + 256*cos^2*CW^4*MB^6*MC^2*MZ^2*s^4*SW^4 + 
   832*CW^2*MB^4*MC^4*MZ^2*s^4*SW^4 - 832*cos^2*CW^2*MB^4*MC^4*MZ^2*s^4*
    SW^4 - 1024*CW^4*MB^4*MC^4*MZ^2*s^4*SW^4 + 1024*cos^2*CW^4*MB^4*MC^4*MZ^2*
    s^4*SW^4 + 640*CW^2*MB^2*MC^6*MZ^2*s^4*SW^4 - 
   640*cos^2*CW^2*MB^2*MC^6*MZ^2*s^4*SW^4 - 1024*CW^4*MB^2*MC^6*MZ^2*s^4*
    SW^4 + 1024*cos^2*CW^4*MB^2*MC^6*MZ^2*s^4*SW^4 + 184*MB^6*MC^2*s^5*SW^4 - 
   184*cos^2*MB^6*MC^2*s^5*SW^4 - 256*CW^2*MB^6*MC^2*s^5*SW^4 + 
   256*cos^2*CW^2*MB^6*MC^2*s^5*SW^4 + 128*CW^4*MB^6*MC^2*s^5*SW^4 - 
   128*cos^2*CW^4*MB^6*MC^2*s^5*SW^4 + 496*MB^4*MC^4*s^5*SW^4 - 
   496*cos^2*MB^4*MC^4*s^5*SW^4 - 832*CW^2*MB^4*MC^4*s^5*SW^4 + 
   832*cos^2*CW^2*MB^4*MC^4*s^5*SW^4 + 512*CW^4*MB^4*MC^4*s^5*SW^4 - 
   512*cos^2*CW^4*MB^4*MC^4*s^5*SW^4 + 328*MB^2*MC^6*s^5*SW^4 - 
   328*cos^2*MB^2*MC^6*s^5*SW^4 - 640*CW^2*MB^2*MC^6*s^5*SW^4 + 
   640*cos^2*CW^2*MB^2*MC^6*s^5*SW^4 + 512*CW^4*MB^2*MC^6*s^5*SW^4 - 
   512*cos^2*CW^4*MB^2*MC^6*s^5*SW^4 + 1536*cos*MB^12*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 7680*cos*MB^11*MC*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 15360*cos*MB^10*MC^2*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 18432*cos*MB^9*MC^3*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 21504*cos*MB^8*MC^4*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 24576*cos*MB^7*MC^5*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 15360*cos*MB^6*MC^6*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 3072*cos*MB^5*MC^7*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 19968*cos*MB^4*MC^8*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 32256*cos*MB^3*MC^9*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 30720*cos*MB^2*MC^10*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 15360*cos*MB*MC^11*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 3072*cos*MC^12*s^(5/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 384*cos*MB^10*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 1152*cos*MB^9*MC*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 1152*cos*MB^8*MC^2*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 1152*cos*MB^7*MC^3*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 1920*cos*MB^6*MC^4*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 - 1152*cos*MB^5*MC^5*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 384*cos*MB^4*MC^6*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 1152*cos*MB^3*MC^7*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 2304*cos*MB^2*MC^8*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 2304*cos*MB*MC^9*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 768*cos*MC^10*s^(7/2)*
    Sqrt[-4*MB^2 - 8*MB*MC - 4*MC^2 + s]*SW^4 + 12288*CW^2*MB^14*MZ^2*s*
    SW^6 - 12288*cos^2*CW^2*MB^14*MZ^2*s*SW^6 + 73728*CW^2*MB^13*MC*MZ^2*s*
    SW^6 - 73728*cos^2*CW^2*MB^13*MC*MZ^2*s*SW^6 + 
   184320*CW^2*MB^12*MC^2*MZ^2*s*SW^6 - 184320*cos^2*CW^2*MB^12*MC^2*MZ^2*s*
    SW^6 + 245760*CW^2*MB^11*MC^3*MZ^2*s*SW^6 - 245760*cos^2*CW^2*MB^11*MC^3*
    MZ^2*s*SW^6 + 233472*CW^2*MB^10*MC^4*MZ^2*s*SW^6 - 
   233472*cos^2*CW^2*MB^10*MC^4*MZ^2*s*SW^6 + 368640*CW^2*MB^9*MC^5*MZ^2*s*
    SW^6 - 368640*cos^2*CW^2*MB^9*MC^5*MZ^2*s*SW^6 + 
   749568*CW^2*MB^8*MC^6*MZ^2*s*SW^6 - 749568*cos^2*CW^2*MB^8*MC^6*MZ^2*s*
    SW^6 + 983040*CW^2*MB^7*MC^7*MZ^2*s*SW^6 - 983040*cos^2*CW^2*MB^7*MC^7*
    MZ^2*s*SW^6 + 786432*CW^2*MB^6*MC^8*MZ^2*s*SW^6 - 
   786432*cos^2*CW^2*MB^6*MC^8*MZ^2*s*SW^6 + 589824*CW^2*MB^5*MC^9*MZ^2*s*
    SW^6 - 589824*cos^2*CW^2*MB^5*MC^9*MZ^2*s*SW^6 + 
   786432*CW^2*MB^4*MC^10*MZ^2*s*SW^6 - 786432*cos^2*CW^2*MB^4*MC^10*MZ^2*s*
    SW^6 + 983040*CW^2*MB^3*MC^11*MZ^2*s*SW^6 - 983040*cos^2*CW^2*MB^3*MC^11*
    MZ^2*s*SW^6 + 737280*CW^2*MB^2*MC^12*MZ^2*s*SW^6 - 
   737280*cos^2*CW^2*MB^2*MC^12*MZ^2*s*SW^6 + 294912*CW^2*MB*MC^13*MZ^2*s*
    SW^6 - 294912*cos^2*CW^2*MB*MC^13*MZ^2*s*SW^6 + 
   49152*CW^2*MC^14*MZ^2*s*SW^6 - 49152*cos^2*CW^2*MC^14*MZ^2*s*SW^6 + 
   12288*MB^14*s^2*SW^6 - 12288*cos^2*MB^14*s^2*SW^6 - 
   12288*CW^2*MB^14*s^2*SW^6 + 12288*cos^2*CW^2*MB^14*s^2*SW^6 + 
   73728*MB^13*MC*s^2*SW^6 - 73728*cos^2*MB^13*MC*s^2*SW^6 - 
   73728*CW^2*MB^13*MC*s^2*SW^6 + 73728*cos^2*CW^2*MB^13*MC*s^2*SW^6 + 
   184320*MB^12*MC^2*s^2*SW^6 - 184320*cos^2*MB^12*MC^2*s^2*SW^6 - 
   184320*CW^2*MB^12*MC^2*s^2*SW^6 + 184320*cos^2*CW^2*MB^12*MC^2*s^2*SW^6 + 
   245760*MB^11*MC^3*s^2*SW^6 - 245760*cos^2*MB^11*MC^3*s^2*SW^6 - 
   245760*CW^2*MB^11*MC^3*s^2*SW^6 + 245760*cos^2*CW^2*MB^11*MC^3*s^2*SW^6 + 
   224256*MB^10*MC^4*s^2*SW^6 - 224256*cos^2*MB^10*MC^4*s^2*SW^6 - 
   233472*CW^2*MB^10*MC^4*s^2*SW^6 + 233472*cos^2*CW^2*MB^10*MC^4*s^2*SW^6 + 
   313344*MB^9*MC^5*s^2*SW^6 - 313344*cos^2*MB^9*MC^5*s^2*SW^6 - 
   368640*CW^2*MB^9*MC^5*s^2*SW^6 + 368640*cos^2*CW^2*MB^9*MC^5*s^2*SW^6 + 
   611328*MB^8*MC^6*s^2*SW^6 - 611328*cos^2*MB^8*MC^6*s^2*SW^6 - 
   749568*CW^2*MB^8*MC^6*s^2*SW^6 + 749568*cos^2*CW^2*MB^8*MC^6*s^2*SW^6 + 
   798720*MB^7*MC^7*s^2*SW^6 - 798720*cos^2*MB^7*MC^7*s^2*SW^6 - 
   983040*CW^2*MB^7*MC^7*s^2*SW^6 + 983040*cos^2*CW^2*MB^7*MC^7*s^2*SW^6 + 
   629760*MB^6*MC^8*s^2*SW^6 - 629760*cos^2*MB^6*MC^8*s^2*SW^6 - 
   786432*CW^2*MB^6*MC^8*s^2*SW^6 + 786432*cos^2*CW^2*MB^6*MC^8*s^2*SW^6 + 
   423936*MB^5*MC^9*s^2*SW^6 - 423936*cos^2*MB^5*MC^9*s^2*SW^6 - 
   589824*CW^2*MB^5*MC^9*s^2*SW^6 + 589824*cos^2*CW^2*MB^5*MC^9*s^2*SW^6 + 
   500736*MB^4*MC^10*s^2*SW^6 - 500736*cos^2*MB^4*MC^10*s^2*SW^6 - 
   786432*CW^2*MB^4*MC^10*s^2*SW^6 + 786432*cos^2*CW^2*MB^4*MC^10*s^2*SW^6 + 
   614400*MB^3*MC^11*s^2*SW^6 - 614400*cos^2*MB^3*MC^11*s^2*SW^6 - 
   983040*CW^2*MB^3*MC^11*s^2*SW^6 + 983040*cos^2*CW^2*MB^3*MC^11*s^2*SW^6 + 
   460800*MB^2*MC^12*s^2*SW^6 - 460800*cos^2*MB^2*MC^12*s^2*SW^6 - 
   737280*CW^2*MB^2*MC^12*s^2*SW^6 + 737280*cos^2*CW^2*MB^2*MC^12*s^2*SW^6 + 
   184320*MB*MC^13*s^2*SW^6 - 184320*cos^2*MB*MC^13*s^2*SW^6 - 
   294912*CW^2*MB*MC^13*s^2*SW^6 + 294912*cos^2*CW^2*MB*MC^13*s^2*SW^6 + 
   30720*MC^14*s^2*SW^6 - 30720*cos^2*MC^14*s^2*SW^6 - 
   49152*CW^2*MC^14*s^2*SW^6 + 49152*cos^2*CW^2*MC^14*s^2*SW^6 - 
   1024*CW^2*MB^12*MZ^2*s^2*SW^6 + 5120*cos^2*CW^2*MB^12*MZ^2*s^2*SW^6 + 
   4096*CW^2*MB^11*MC*MZ^2*s^2*SW^6 + 20480*cos^2*CW^2*MB^11*MC*MZ^2*s^2*
    SW^6 + 28672*CW^2*MB^10*MC^2*MZ^2*s^2*SW^6 + 32768*cos^2*CW^2*MB^10*MC^2*
    MZ^2*s^2*SW^6 + 69632*CW^2*MB^9*MC^3*MZ^2*s^2*SW^6 + 
   28672*cos^2*CW^2*MB^9*MC^3*MZ^2*s^2*SW^6 + 113664*CW^2*MB^8*MC^4*MZ^2*s^2*
    SW^6 + 46080*cos^2*CW^2*MB^8*MC^4*MZ^2*s^2*SW^6 + 
   147456*CW^2*MB^7*MC^5*MZ^2*s^2*SW^6 + 122880*cos^2*CW^2*MB^7*MC^5*MZ^2*s^2*
    SW^6 + 165888*CW^2*MB^6*MC^6*MZ^2*s^2*SW^6 + 182272*cos^2*CW^2*MB^6*MC^6*
    MZ^2*s^2*SW^6 + 196608*CW^2*MB^5*MC^7*MZ^2*s^2*SW^6 + 
   147456*cos^2*CW^2*MB^5*MC^7*MZ^2*s^2*SW^6 + 245760*CW^2*MB^4*MC^8*MZ^2*s^2*
    SW^6 + 98304*cos^2*CW^2*MB^4*MC^8*MZ^2*s^2*SW^6 + 
   229376*CW^2*MB^3*MC^9*MZ^2*s^2*SW^6 + 114688*cos^2*CW^2*MB^3*MC^9*MZ^2*s^2*
    SW^6 + 114688*CW^2*MB^2*MC^10*MZ^2*s^2*SW^6 + 
   131072*cos^2*CW^2*MB^2*MC^10*MZ^2*s^2*SW^6 + 16384*CW^2*MB*MC^11*MZ^2*s^2*
    SW^6 + 81920*cos^2*CW^2*MB*MC^11*MZ^2*s^2*SW^6 - 
   4096*CW^2*MC^12*MZ^2*s^2*SW^6 + 20480*cos^2*CW^2*MC^12*MZ^2*s^2*SW^6 - 
   1024*MB^12*s^3*SW^6 + 5120*cos^2*MB^12*s^3*SW^6 + 
   1024*CW^2*MB^12*s^3*SW^6 - 5120*cos^2*CW^2*MB^12*s^3*SW^6 + 
   4096*MB^11*MC*s^3*SW^6 + 20480*cos^2*MB^11*MC*s^3*SW^6 - 
   4096*CW^2*MB^11*MC*s^3*SW^6 - 20480*cos^2*CW^2*MB^11*MC*s^3*SW^6 + 
   28672*MB^10*MC^2*s^3*SW^6 + 32768*cos^2*MB^10*MC^2*s^3*SW^6 - 
   28672*CW^2*MB^10*MC^2*s^3*SW^6 - 32768*cos^2*CW^2*MB^10*MC^2*s^3*SW^6 + 
   66560*MB^9*MC^3*s^3*SW^6 + 28672*cos^2*MB^9*MC^3*s^3*SW^6 - 
   69632*CW^2*MB^9*MC^3*s^3*SW^6 - 28672*cos^2*CW^2*MB^9*MC^3*s^3*SW^6 + 
   100608*MB^8*MC^4*s^3*SW^6 + 40704*cos^2*MB^8*MC^4*s^3*SW^6 - 
   113664*CW^2*MB^8*MC^4*s^3*SW^6 - 46080*cos^2*CW^2*MB^8*MC^4*s^3*SW^6 + 
   122880*MB^7*MC^5*s^3*SW^6 + 101376*cos^2*MB^7*MC^5*s^3*SW^6 - 
   147456*CW^2*MB^7*MC^5*s^3*SW^6 - 122880*cos^2*CW^2*MB^7*MC^5*s^3*SW^6 + 
   133632*MB^6*MC^6*s^3*SW^6 + 146944*cos^2*MB^6*MC^6*s^3*SW^6 - 
   165888*CW^2*MB^6*MC^6*s^3*SW^6 - 182272*cos^2*CW^2*MB^6*MC^6*s^3*SW^6 + 
   147456*MB^5*MC^7*s^3*SW^6 + 113664*cos^2*MB^5*MC^7*s^3*SW^6 - 
   196608*CW^2*MB^5*MC^7*s^3*SW^6 - 147456*cos^2*CW^2*MB^5*MC^7*s^3*SW^6 + 
   166656*MB^4*MC^8*s^3*SW^6 + 66816*cos^2*MB^4*MC^8*s^3*SW^6 - 
   245760*CW^2*MB^4*MC^8*s^3*SW^6 - 98304*cos^2*CW^2*MB^4*MC^8*s^3*SW^6 + 
   146432*MB^3*MC^9*s^3*SW^6 + 71680*cos^2*MB^3*MC^9*s^3*SW^6 - 
   229376*CW^2*MB^3*MC^9*s^3*SW^6 - 114688*cos^2*CW^2*MB^3*MC^9*s^3*SW^6 + 
   71680*MB^2*MC^10*s^3*SW^6 + 81920*cos^2*MB^2*MC^10*s^3*SW^6 - 
   114688*CW^2*MB^2*MC^10*s^3*SW^6 - 131072*cos^2*CW^2*MB^2*MC^10*s^3*SW^6 + 
   10240*MB*MC^11*s^3*SW^6 + 51200*cos^2*MB*MC^11*s^3*SW^6 - 
   16384*CW^2*MB*MC^11*s^3*SW^6 - 81920*cos^2*CW^2*MB*MC^11*s^3*SW^6 - 
   2560*MC^12*s^3*SW^6 + 12800*cos^2*MC^12*s^3*SW^6 + 
   4096*CW^2*MC^12*s^3*SW^6 - 20480*cos^2*CW^2*MC^12*s^3*SW^6 - 
   512*CW^2*MB^10*MZ^2*s^3*SW^6 - 512*cos^2*CW^2*MB^10*MZ^2*s^3*SW^6 - 
   3072*CW^2*MB^9*MC*MZ^2*s^3*SW^6 - 1024*cos^2*CW^2*MB^9*MC*MZ^2*s^3*SW^6 - 
   4096*CW^2*MB^8*MC^2*MZ^2*s^3*SW^6 - 2048*cos^2*CW^2*MB^8*MC^2*MZ^2*s^3*
    SW^6 - 5120*CW^2*MB^7*MC^3*MZ^2*s^3*SW^6 - 3072*cos^2*CW^2*MB^7*MC^3*MZ^2*
    s^3*SW^6 - 7680*CW^2*MB^6*MC^4*MZ^2*s^3*SW^6 - 
   9728*cos^2*CW^2*MB^6*MC^4*MZ^2*s^3*SW^6 - 8192*CW^2*MB^5*MC^5*MZ^2*s^3*
    SW^6 - 16384*cos^2*CW^2*MB^5*MC^5*MZ^2*s^3*SW^6 - 
   6144*CW^2*MB^4*MC^6*MZ^2*s^3*SW^6 - 14336*cos^2*CW^2*MB^4*MC^6*MZ^2*s^3*
    SW^6 - 8192*CW^2*MB^3*MC^7*MZ^2*s^3*SW^6 - 12288*cos^2*CW^2*MB^3*MC^7*
    MZ^2*s^3*SW^6 - 16384*CW^2*MB^2*MC^8*MZ^2*s^3*SW^6 - 
   8192*cos^2*CW^2*MB^2*MC^8*MZ^2*s^3*SW^6 - 12288*CW^2*MB*MC^9*MZ^2*s^3*
    SW^6 - 4096*cos^2*CW^2*MB*MC^9*MZ^2*s^3*SW^6 - 
   2048*CW^2*MC^10*MZ^2*s^3*SW^6 - 2048*cos^2*CW^2*MC^10*MZ^2*s^3*SW^6 - 
   512*MB^10*s^4*SW^6 - 512*cos^2*MB^10*s^4*SW^6 + 512*CW^2*MB^10*s^4*SW^6 + 
   512*cos^2*CW^2*MB^10*s^4*SW^6 - 3072*MB^9*MC*s^4*SW^6 - 
   1024*cos^2*MB^9*MC*s^4*SW^6 + 3072*CW^2*MB^9*MC*s^4*SW^6 + 
   1024*cos^2*CW^2*MB^9*MC*s^4*SW^6 - 4096*MB^8*MC^2*s^4*SW^6 - 
   2048*cos^2*MB^8*MC^2*s^4*SW^6 + 4096*CW^2*MB^8*MC^2*s^4*SW^6 + 
   2048*cos^2*CW^2*MB^8*MC^2*s^4*SW^6 - 4352*MB^7*MC^3*s^4*SW^6 - 
   3072*cos^2*MB^7*MC^3*s^4*SW^6 + 5120*CW^2*MB^7*MC^3*s^4*SW^6 + 
   3072*cos^2*CW^2*MB^7*MC^3*s^4*SW^6 - 6144*MB^6*MC^4*s^4*SW^6 - 
   8192*cos^2*MB^6*MC^4*s^4*SW^6 + 7680*CW^2*MB^6*MC^4*s^4*SW^6 + 
   9728*cos^2*CW^2*MB^6*MC^4*s^4*SW^6 - 6656*MB^5*MC^5*s^4*SW^6 - 
   13312*cos^2*MB^5*MC^5*s^4*SW^6 + 8192*CW^2*MB^5*MC^5*s^4*SW^6 + 
   16384*cos^2*CW^2*MB^5*MC^5*s^4*SW^6 - 5376*MB^4*MC^6*s^4*SW^6 - 
   10496*cos^2*MB^4*MC^6*s^4*SW^6 + 6144*CW^2*MB^4*MC^6*s^4*SW^6 + 
   14336*cos^2*CW^2*MB^4*MC^6*s^4*SW^6 - 5888*MB^3*MC^7*s^4*SW^6 - 
   7680*cos^2*MB^3*MC^7*s^4*SW^6 + 8192*CW^2*MB^3*MC^7*s^4*SW^6 + 
   12288*cos^2*CW^2*MB^3*MC^7*s^4*SW^6 - 10240*MB^2*MC^8*s^4*SW^6 - 
   5120*cos^2*MB^2*MC^8*s^4*SW^6 + 16384*CW^2*MB^2*MC^8*s^4*SW^6 + 
   8192*cos^2*CW^2*MB^2*MC^8*s^4*SW^6 - 7680*MB*MC^9*s^4*SW^6 - 
   2560*cos^2*MB*MC^9*s^4*SW^6 + 12288*CW^2*MB*MC^9*s^4*SW^6 + 
   4096*cos^2*CW^2*MB*MC^9*s^4*SW^6 - 1280*MC^10*s^4*SW^6 - 
   1280*cos^2*MC^10*s^4*SW^6 + 2048*CW^2*MC^10*s^4*SW^6 + 
   2048*cos^2*CW^2*MC^10*s^4*SW^6 - 256*CW^2*MB^6*MC^2*MZ^2*s^4*SW^6 + 
   256*cos^2*CW^2*MB^6*MC^2*MZ^2*s^4*SW^6 - 1024*CW^2*MB^4*MC^4*MZ^2*s^4*
    SW^6 + 1024*cos^2*CW^2*MB^4*MC^4*MZ^2*s^4*SW^6 - 
   1024*CW^2*MB^2*MC^6*MZ^2*s^4*SW^6 + 1024*cos^2*CW^2*MB^2*MC^6*MZ^2*s^4*
    SW^6 - 256*MB^6*MC^2*s^5*SW^6 + 256*cos^2*MB^6*MC^2*s^5*SW^6 + 
   256*CW^2*MB^6*MC^2*s^5*SW^6 - 256*cos^2*CW^2*MB^6*MC^2*s^5*SW^6 - 
   832*MB^4*MC^4*s^5*SW^6 + 832*cos^2*MB^4*MC^4*s^5*SW^6 + 
   1024*CW^2*MB^4*MC^4*s^5*SW^6 - 1024*cos^2*CW^2*MB^4*MC^4*s^5*SW^6 - 
   640*MB^2*MC^6*s^5*SW^6 + 640*cos^2*MB^2*MC^6*s^5*SW^6 + 
   1024*CW^2*MB^2*MC^6*s^5*SW^6 - 1024*cos^2*CW^2*MB^2*MC^6*s^5*SW^6 - 
   6144*MB^14*s^2*SW^8 + 6144*cos^2*MB^14*s^2*SW^8 - 
   36864*MB^13*MC*s^2*SW^8 + 36864*cos^2*MB^13*MC*s^2*SW^8 - 
   92160*MB^12*MC^2*s^2*SW^8 + 92160*cos^2*MB^12*MC^2*s^2*SW^8 - 
   122880*MB^11*MC^3*s^2*SW^8 + 122880*cos^2*MB^11*MC^3*s^2*SW^8 - 
   116736*MB^10*MC^4*s^2*SW^8 + 116736*cos^2*MB^10*MC^4*s^2*SW^8 - 
   184320*MB^9*MC^5*s^2*SW^8 + 184320*cos^2*MB^9*MC^5*s^2*SW^8 - 
   374784*MB^8*MC^6*s^2*SW^8 + 374784*cos^2*MB^8*MC^6*s^2*SW^8 - 
   491520*MB^7*MC^7*s^2*SW^8 + 491520*cos^2*MB^7*MC^7*s^2*SW^8 - 
   393216*MB^6*MC^8*s^2*SW^8 + 393216*cos^2*MB^6*MC^8*s^2*SW^8 - 
   294912*MB^5*MC^9*s^2*SW^8 + 294912*cos^2*MB^5*MC^9*s^2*SW^8 - 
   393216*MB^4*MC^10*s^2*SW^8 + 393216*cos^2*MB^4*MC^10*s^2*SW^8 - 
   491520*MB^3*MC^11*s^2*SW^8 + 491520*cos^2*MB^3*MC^11*s^2*SW^8 - 
   368640*MB^2*MC^12*s^2*SW^8 + 368640*cos^2*MB^2*MC^12*s^2*SW^8 - 
   147456*MB*MC^13*s^2*SW^8 + 147456*cos^2*MB*MC^13*s^2*SW^8 - 
   24576*MC^14*s^2*SW^8 + 24576*cos^2*MC^14*s^2*SW^8 + 512*MB^12*s^3*SW^8 - 
   2560*cos^2*MB^12*s^3*SW^8 - 2048*MB^11*MC*s^3*SW^8 - 
   10240*cos^2*MB^11*MC*s^3*SW^8 - 14336*MB^10*MC^2*s^3*SW^8 - 
   16384*cos^2*MB^10*MC^2*s^3*SW^8 - 34816*MB^9*MC^3*s^3*SW^8 - 
   14336*cos^2*MB^9*MC^3*s^3*SW^8 - 56832*MB^8*MC^4*s^3*SW^8 - 
   23040*cos^2*MB^8*MC^4*s^3*SW^8 - 73728*MB^7*MC^5*s^3*SW^8 - 
   61440*cos^2*MB^7*MC^5*s^3*SW^8 - 82944*MB^6*MC^6*s^3*SW^8 - 
   91136*cos^2*MB^6*MC^6*s^3*SW^8 - 98304*MB^5*MC^7*s^3*SW^8 - 
   73728*cos^2*MB^5*MC^7*s^3*SW^8 - 122880*MB^4*MC^8*s^3*SW^8 - 
   49152*cos^2*MB^4*MC^8*s^3*SW^8 - 114688*MB^3*MC^9*s^3*SW^8 - 
   57344*cos^2*MB^3*MC^9*s^3*SW^8 - 57344*MB^2*MC^10*s^3*SW^8 - 
   65536*cos^2*MB^2*MC^10*s^3*SW^8 - 8192*MB*MC^11*s^3*SW^8 - 
   40960*cos^2*MB*MC^11*s^3*SW^8 + 2048*MC^12*s^3*SW^8 - 
   10240*cos^2*MC^12*s^3*SW^8 + 256*MB^10*s^4*SW^8 + 
   256*cos^2*MB^10*s^4*SW^8 + 1536*MB^9*MC*s^4*SW^8 + 
   512*cos^2*MB^9*MC*s^4*SW^8 + 2048*MB^8*MC^2*s^4*SW^8 + 
   1024*cos^2*MB^8*MC^2*s^4*SW^8 + 2560*MB^7*MC^3*s^4*SW^8 + 
   1536*cos^2*MB^7*MC^3*s^4*SW^8 + 3840*MB^6*MC^4*s^4*SW^8 + 
   4864*cos^2*MB^6*MC^4*s^4*SW^8 + 4096*MB^5*MC^5*s^4*SW^8 + 
   8192*cos^2*MB^5*MC^5*s^4*SW^8 + 3072*MB^4*MC^6*s^4*SW^8 + 
   7168*cos^2*MB^4*MC^6*s^4*SW^8 + 4096*MB^3*MC^7*s^4*SW^8 + 
   6144*cos^2*MB^3*MC^7*s^4*SW^8 + 8192*MB^2*MC^8*s^4*SW^8 + 
   4096*cos^2*MB^2*MC^8*s^4*SW^8 + 6144*MB*MC^9*s^4*SW^8 + 
   2048*cos^2*MB*MC^9*s^4*SW^8 + 1024*MC^10*s^4*SW^8 + 
   1024*cos^2*MC^10*s^4*SW^8 + 128*MB^6*MC^2*s^5*SW^8 - 
   128*cos^2*MB^6*MC^2*s^5*SW^8 + 512*MB^4*MC^4*s^5*SW^8 - 
   512*cos^2*MB^4*MC^4*s^5*SW^8 + 512*MB^2*MC^6*s^5*SW^8 - 
   512*cos^2*MB^2*MC^6*s^5*SW^8))/(93312*CW^4*MB^6*MC^6*s^(13/2)*
  ((-I)*GammaZ*MZ - MZ^2 + s)*(I*GammaZ*MZ - MZ^2 + s)*SW^4)
